#!/usr/bin/env swift
// CalendarHelper.swift — Standalone CLI for macOS Calendar access via EventKit.
// Compiled binary gets its own TCC identity, bypassing terminal app permission issues.
// Usage: calendar-helper <command> [args...]
//   list-calendars
//   list-events <start_iso> <end_iso> [calendar_id]
//   search-events <query> [days_back] [days_forward]
//   create-event <title> <start_iso> <end_iso> <calendar_id> [--location X] [--notes X] [--all-day] [--recurrence daily|weekly|monthly|yearly] [--interval N] [--recurrence-end DATE] [--recurrence-count N] [--recurrence-days 1,3,5]
//   modify-event <event_id> [--title X] [--start X] [--end X] [--location X] [--notes X]
//   delete-event <event_id>
//   check-access
// Output: JSON to stdout. Errors to stderr.

import EventKit
import Foundation

let store = EKEventStore()
let semaphore = DispatchSemaphore(value: 0)

// MARK: - Permission Request

func requestAccess() -> Bool {
    var granted = false
    if #available(macOS 14.0, *) {
        store.requestFullAccessToEvents { g, error in
            granted = g
            if let error = error {
                printErr("Permission error: \(error.localizedDescription)")
            }
            semaphore.signal()
        }
    } else {
        store.requestAccess(to: .event) { g, error in
            granted = g
            if let error = error {
                printErr("Permission error: \(error.localizedDescription)")
            }
            semaphore.signal()
        }
    }
    semaphore.wait()
    return granted
}

// MARK: - Calendar Sync

/// Force the Calendar daemon to reload and sync changes to the CalDAV server.
/// Without this, changes made from daemonized processes (PM2, nohup, launchd)
/// are written to the local EventKit database but the sync daemon never learns
/// about them. The next CalDAV pull then overwrites the local change with the
/// server's stale version — causing the "moves for a second, then reverts" bug.
func forceCalendarSync() {
    let task = Process()
    task.executableURL = URL(fileURLWithPath: "/usr/bin/osascript")
    task.arguments = ["-e", "tell application \"Calendar\" to reload calendars"]
    task.standardOutput = FileHandle.nullDevice
    task.standardError = FileHandle.nullDevice
    try? task.run()
    task.waitUntilExit()
}

// MARK: - Helpers

func printErr(_ msg: String) {
    FileHandle.standardError.write(Data((msg + "\n").utf8))
}

func printJSON(_ obj: Any) {
    if let data = try? JSONSerialization.data(withJSONObject: obj, options: [.prettyPrinted, .sortedKeys]),
       let str = String(data: data, encoding: .utf8) {
        print(str)
    }
}

func isoFormatter() -> ISO8601DateFormatter {
    let f = ISO8601DateFormatter()
    f.formatOptions = [.withInternetDateTime]
    return f
}

func flexibleParseDate(_ str: String) -> Date? {
    // Try ISO8601 first
    let iso = isoFormatter()
    if let d = iso.date(from: str) { return d }
    // Try date-only format (YYYY-MM-DD) — interpret as midnight local time
    let df = DateFormatter()
    df.dateFormat = "yyyy-MM-dd"
    df.timeZone = TimeZone.current
    if let d = df.date(from: str) { return d }
    // Try datetime without timezone
    df.dateFormat = "yyyy-MM-dd'T'HH:mm:ss"
    if let d = df.date(from: str) { return d }
    return nil
}

func formatDate(_ date: Date) -> String {
    return isoFormatter().string(from: date)
}

func calendarDict(_ cal: EKCalendar) -> [String: Any] {
    return [
        "id": cal.calendarIdentifier,
        "title": cal.title,
        "type": calendarTypeName(cal.type),
        "source": cal.source?.title ?? "Unknown",
        "editable": cal.allowsContentModifications,
        "subscribed": cal.isSubscribed,
    ]
}

func calendarTypeName(_ type: EKCalendarType) -> String {
    switch type {
    case .local: return "local"
    case .calDAV: return "calDAV"
    case .exchange: return "exchange"
    case .subscription: return "subscription"
    case .birthday: return "birthday"
    @unknown default: return "unknown"
    }
}

func recurrenceDescription(_ rule: EKRecurrenceRule) -> [String: Any] {
    var r: [String: Any] = [:]
    switch rule.frequency {
    case .daily: r["frequency"] = "daily"
    case .weekly: r["frequency"] = "weekly"
    case .monthly: r["frequency"] = "monthly"
    case .yearly: r["frequency"] = "yearly"
    @unknown default: r["frequency"] = "unknown"
    }
    r["interval"] = rule.interval
    if let end = rule.recurrenceEnd {
        if let endDate = end.endDate {
            r["end_date"] = formatDate(endDate)
        } else if end.occurrenceCount > 0 {
            r["count"] = end.occurrenceCount
        }
    }
    if let days = rule.daysOfTheWeek {
        let dayNames = ["", "SU", "MO", "TU", "WE", "TH", "FR", "SA"]
        r["days"] = days.map { dayNames[min($0.dayOfTheWeek.rawValue, 7)] }
    }
    return r
}

func parseRecurrenceRule(_ frequency: String, interval: Int, endDateStr: String?, count: Int?, daysOfWeek: [Int]?) -> EKRecurrenceRule? {
    let freq: EKRecurrenceFrequency
    switch frequency.lowercased() {
    case "daily": freq = .daily
    case "weekly": freq = .weekly
    case "monthly": freq = .monthly
    case "yearly": freq = .yearly
    default:
        printErr("Unknown recurrence frequency: \(frequency). Use: daily, weekly, monthly, yearly")
        return nil
    }

    var recEnd: EKRecurrenceEnd? = nil
    if let endStr = endDateStr, let endDate = flexibleParseDate(endStr) {
        recEnd = EKRecurrenceEnd(end: endDate)
    } else if let c = count, c > 0 {
        recEnd = EKRecurrenceEnd(occurrenceCount: c)
    }

    var dayRules: [EKRecurrenceDayOfWeek]? = nil
    if let days = daysOfWeek {
        dayRules = days.compactMap { num -> EKRecurrenceDayOfWeek? in
            guard num >= 1 && num <= 7 else { return nil }
            return EKRecurrenceDayOfWeek(EKWeekday(rawValue: num)!)
        }
    }

    return EKRecurrenceRule(
        recurrenceWith: freq,
        interval: interval,
        daysOfTheWeek: dayRules,
        daysOfTheMonth: nil,
        monthsOfTheYear: nil,
        weeksOfTheYear: nil,
        daysOfTheYear: nil,
        setPositions: nil,
        end: recEnd
    )
}

func eventDict(_ event: EKEvent) -> [String: Any] {
    var d: [String: Any] = [
        "id": event.eventIdentifier ?? "",
        "title": event.title ?? "",
        "start": formatDate(event.startDate),
        "end": formatDate(event.endDate),
        "all_day": event.isAllDay,
        "calendar_id": event.calendar.calendarIdentifier,
        "calendar_title": event.calendar.title,
    ]
    if let loc = event.location, !loc.isEmpty { d["location"] = loc }
    if let notes = event.notes, !notes.isEmpty { d["notes"] = notes }
    if let url = event.url { d["url"] = url.absoluteString }
    if event.hasRecurrenceRules, let rules = event.recurrenceRules, let first = rules.first {
        d["recurrence"] = recurrenceDescription(first)
    }
    return d
}

// MARK: - Commands

func listCalendars() {
    let calendars = store.calendars(for: .event)
    let result = calendars.map { calendarDict($0) }
    printJSON(["calendars": result, "count": result.count])
}

func listEvents(startStr: String, endStr: String, calendarId: String?) {
    guard let start = flexibleParseDate(startStr) else {
        printErr("Invalid start date: \(startStr)")
        exit(1)
    }
    guard let end = flexibleParseDate(endStr) else {
        printErr("Invalid end date: \(endStr)")
        exit(1)
    }

    var calendars: [EKCalendar]? = nil
    if let cid = calendarId {
        let allCals = store.calendars(for: .event)
        let matched = allCals.filter { $0.calendarIdentifier == cid }
        if matched.isEmpty {
            printErr("Calendar not found: \(cid)")
            exit(1)
        }
        calendars = matched
    }

    let predicate = store.predicateForEvents(withStart: start, end: end, calendars: calendars)
    let events = store.events(matching: predicate).sorted { $0.startDate < $1.startDate }
    let result = events.map { eventDict($0) }
    printJSON(["events": result, "count": result.count, "start": formatDate(start), "end": formatDate(end)])
}

func searchEvents(query: String, daysBack: Int, daysForward: Int) {
    let now = Date()
    let start = Calendar.current.date(byAdding: .day, value: -daysBack, to: now)!
    let end = Calendar.current.date(byAdding: .day, value: daysForward, to: now)!

    let predicate = store.predicateForEvents(withStart: start, end: end, calendars: nil)
    let allEvents = store.events(matching: predicate)
    let queryLower = query.lowercased()

    let matched = allEvents.filter { event in
        (event.title?.lowercased().contains(queryLower) ?? false) ||
        (event.notes?.lowercased().contains(queryLower) ?? false) ||
        (event.location?.lowercased().contains(queryLower) ?? false)
    }.sorted { $0.startDate < $1.startDate }

    let result = matched.map { eventDict($0) }
    printJSON(["events": result, "count": result.count, "query": query])
}

func createEvent(title: String, startStr: String, endStr: String, calendarId: String, extraArgs: [String]) {
    guard let start = flexibleParseDate(startStr) else {
        printErr("Invalid start date: \(startStr)")
        exit(1)
    }
    guard let end = flexibleParseDate(endStr) else {
        printErr("Invalid end date: \(endStr)")
        exit(1)
    }

    let allCals = store.calendars(for: .event)
    guard let cal = allCals.first(where: { $0.calendarIdentifier == calendarId }) else {
        printErr("Calendar not found: \(calendarId)")
        printErr("Available calendars:")
        for c in allCals { printErr("  \(c.title) — \(c.calendarIdentifier)") }
        exit(1)
    }

    guard cal.allowsContentModifications else {
        printErr("Calendar '\(cal.title)' is read-only")
        exit(1)
    }

    // Parse optional --key value flags
    var location: String? = nil
    var notes: String? = nil
    var allDay = false
    var recurrenceFreq: String? = nil
    var recurrenceInterval = 1
    var recurrenceEnd: String? = nil
    var recurrenceCount: Int? = nil
    var recurrenceDays: [Int]? = nil

    var i = 0
    while i < extraArgs.count {
        let key = extraArgs[i]
        if key == "--all-day" {
            allDay = true
            i += 1
            continue
        }
        guard i + 1 < extraArgs.count else {
            printErr("Missing value for \(key)")
            exit(1)
        }
        let val = extraArgs[i + 1]
        switch key {
        case "--location": location = val
        case "--notes": notes = val
        case "--recurrence": recurrenceFreq = val
        case "--interval": recurrenceInterval = Int(val) ?? 1
        case "--recurrence-end": recurrenceEnd = val
        case "--recurrence-count": recurrenceCount = Int(val)
        case "--recurrence-days":
            // Comma-separated day numbers: 1=Sunday..7=Saturday
            recurrenceDays = val.split(separator: ",").compactMap { Int($0) }
        default: printErr("Unknown flag: \(key)"); exit(1)
        }
        i += 2
    }

    let event = EKEvent(eventStore: store)
    event.title = title
    event.startDate = start
    event.endDate = end
    event.calendar = cal
    event.isAllDay = allDay
    if let loc = location { event.location = loc }
    if let n = notes { event.notes = n }

    if let freq = recurrenceFreq {
        guard let rule = parseRecurrenceRule(freq, interval: recurrenceInterval,
                                             endDateStr: recurrenceEnd, count: recurrenceCount,
                                             daysOfWeek: recurrenceDays) else {
            exit(1)
        }
        event.addRecurrenceRule(rule)
    }

    do {
        let span: EKSpan = event.hasRecurrenceRules ? .futureEvents : .thisEvent
        try store.save(event, span: span)
        forceCalendarSync()
        printJSON(eventDict(event))
    } catch {
        printErr("Failed to save event: \(error.localizedDescription)")
        exit(1)
    }
}

func modifyEvent(eventId: String, args: [String]) {
    guard let event = store.event(withIdentifier: eventId) else {
        printErr("Event not found: \(eventId)")
        exit(1)
    }

    // Parse --key value pairs
    var i = 0
    while i < args.count {
        let key = args[i]
        guard i + 1 < args.count else {
            printErr("Missing value for \(key)")
            exit(1)
        }
        let val = args[i + 1]
        switch key {
        case "--title": event.title = val
        case "--start":
            guard let d = flexibleParseDate(val) else { printErr("Invalid date: \(val)"); exit(1) }
            event.startDate = d
        case "--end":
            guard let d = flexibleParseDate(val) else { printErr("Invalid date: \(val)"); exit(1) }
            event.endDate = d
        case "--location": event.location = val
        case "--notes": event.notes = val
        default: printErr("Unknown flag: \(key)"); exit(1)
        }
        i += 2
    }

    do {
        try store.save(event, span: .thisEvent)
        forceCalendarSync()
        printJSON(eventDict(event))
    } catch {
        printErr("Failed to modify event: \(error.localizedDescription)")
        exit(1)
    }
}

func deleteEvent(eventId: String) {
    guard let event = store.event(withIdentifier: eventId) else {
        printErr("Event not found: \(eventId)")
        exit(1)
    }

    // Print event details so caller can confirm
    printJSON(["deleted": eventDict(event)])

    do {
        try store.remove(event, span: .thisEvent)
        forceCalendarSync()
    } catch {
        printErr("Failed to delete event: \(error.localizedDescription)")
        exit(1)
    }
}

func checkAccess() {
    let status: String
    if #available(macOS 14.0, *) {
        let s = EKEventStore.authorizationStatus(for: .event)
        switch s {
        case .fullAccess: status = "full_access"
        case .writeOnly: status = "write_only"
        case .denied: status = "denied"
        case .restricted: status = "restricted"
        case .notDetermined: status = "not_determined"
        @unknown default: status = "unknown"
        }
    } else {
        let s = EKEventStore.authorizationStatus(for: .event)
        switch s {
        case .authorized: status = "authorized"
        case .denied: status = "denied"
        case .restricted: status = "restricted"
        case .notDetermined: status = "not_determined"
        @unknown default: status = "unknown"
        }
    }
    let calendars = store.calendars(for: .event)
    printJSON([
        "status": status,
        "calendar_count": calendars.count,
        "has_real_calendars": calendars.contains(where: { $0.calendarIdentifier != "VIRTUAL_APP_CALENDAR_UUID" }),
    ])
}

// MARK: - Main

let args = CommandLine.arguments
guard args.count >= 2 else {
    printErr("Usage: calendar-helper <command> [args...]")
    printErr("Commands: check-access, list-calendars, list-events, search-events, create-event, modify-event, delete-event")
    exit(1)
}

// Request access first
guard requestAccess() else {
    printErr("Calendar access denied. Go to System Settings > Privacy & Security > Calendars and enable access for 'calendar-helper'.")
    printJSON(["error": "access_denied", "fix": "System Settings > Privacy & Security > Calendars > enable calendar-helper"])
    exit(1)
}

let command = args[1]
switch command {
case "check-access":
    checkAccess()

case "list-calendars":
    listCalendars()

case "list-events":
    guard args.count >= 4 else {
        printErr("Usage: calendar-helper list-events <start_iso> <end_iso> [calendar_id]")
        exit(1)
    }
    listEvents(startStr: args[2], endStr: args[3], calendarId: args.count > 4 ? args[4] : nil)

case "search-events":
    guard args.count >= 3 else {
        printErr("Usage: calendar-helper search-events <query> [days_back] [days_forward]")
        exit(1)
    }
    let daysBack = args.count > 3 ? Int(args[3]) ?? 30 : 30
    let daysForward = args.count > 4 ? Int(args[4]) ?? 365 : 365
    searchEvents(query: args[2], daysBack: daysBack, daysForward: daysForward)

case "create-event":
    guard args.count >= 6 else {
        printErr("Usage: calendar-helper create-event <title> <start> <end> <calendar_id> [--location X] [--notes X] [--all-day] [--recurrence daily|weekly|monthly|yearly] [--interval N] [--recurrence-end DATE] [--recurrence-count N] [--recurrence-days 1,3,5]")
        exit(1)
    }
    createEvent(
        title: args[2], startStr: args[3], endStr: args[4], calendarId: args[5],
        extraArgs: args.count > 6 ? Array(args[6...]) : []
    )

case "modify-event":
    guard args.count >= 3 else {
        printErr("Usage: calendar-helper modify-event <event_id> [--title X] [--start X] ...")
        exit(1)
    }
    modifyEvent(eventId: args[2], args: Array(args[3...]))

case "delete-event":
    guard args.count >= 3 else {
        printErr("Usage: calendar-helper delete-event <event_id>")
        exit(1)
    }
    deleteEvent(eventId: args[2])

default:
    printErr("Unknown command: \(command)")
    exit(1)
}
