---
name: osx-calendar
version: 2.0.0
description: macOS Calendar access via a compiled Swift EventKit CLI. Use this skill whenever the user asks about their calendar, schedule, agenda, events, meetings, availability, or wants to create/modify/delete calendar events. Also use when the user mentions "tomorrow", "next week", "free time", or any scheduling-related query.
---

# macOS Calendar Integration

Access macOS Calendar via a pre-compiled Swift binary (`calendar-helper`) that talks directly to EventKit. The binary has its own TCC identity, so it works regardless of which terminal app (VSCode, Warp, iTerm, Terminal) you're running in.

## Setup (one-time)

The binary is already compiled at `scripts/calendar-helper` within this skill directory. If it's missing or needs recompilation:

```bash
cd ~/.claude/skills/osx-calendar/scripts
swiftc -O -framework EventKit -framework Foundation CalendarHelper.swift -o calendar-helper
```

### Calendar permissions

The host terminal app (VSCode, Warp, Terminal, iTerm) must have Calendar access:

**System Settings > Privacy & Security > Calendars** — enable your terminal app with "Full Access".

If `calendar-helper` returns only `VIRTUAL_APP_CALENDAR_UUID` or `access_denied`, this is always a TCC permission issue. Guide the user to the setting above.

## How to use

The binary path is: `~/.claude/skills/osx-calendar/scripts/calendar-helper`

All commands output JSON to stdout. Errors go to stderr with exit code 1.

Run commands via Bash tool. Parse the JSON output to present results to the user.

### Commands

#### Check access
```bash
~/.claude/skills/osx-calendar/scripts/calendar-helper check-access
```
Returns: `{ "status": "full_access", "calendar_count": 4, "has_real_calendars": true }`

#### List calendars
```bash
~/.claude/skills/osx-calendar/scripts/calendar-helper list-calendars
```
Returns: `{ "calendars": [...], "count": N }`

Each calendar has: `id`, `title`, `type` (local/calDAV/exchange/subscription/birthday), `source`, `editable`, `subscribed`.

#### List events by date range
```bash
~/.claude/skills/osx-calendar/scripts/calendar-helper list-events <start> <end> [calendar_id]
```
- Dates: ISO 8601 (`2026-03-16T00:00:00+08:00`) or date-only (`2026-03-16`, interpreted as midnight local time)
- Optional `calendar_id` to filter to one calendar

Returns: `{ "events": [...], "count": N }`

Each event has: `id`, `title`, `start`, `end`, `all_day`, `calendar_id`, `calendar_title`, and optionally `location`, `notes`, `url`.

**Common patterns:**
- Tomorrow's agenda: use date-only for start (tomorrow) and end (day after)
- This week: start=Monday, end=next Monday
- Specific calendar: pass `calendar_id` as 3rd argument

#### Search events by text
```bash
~/.claude/skills/osx-calendar/scripts/calendar-helper search-events <query> [days_back] [days_forward]
```
- `query`: case-insensitive search across title, notes, location
- `days_back`: how far back to search (default: 30)
- `days_forward`: how far forward to search (default: 365)

#### Create event
```bash
~/.claude/skills/osx-calendar/scripts/calendar-helper create-event <title> <start> <end> <calendar_id> [flags...]
```
- `calendar_id`: from `list-calendars` — must be an editable calendar

**Optional flags** (all use `--key value` format):
- `--location "Office"` — event location
- `--notes "Bring laptop"` — event notes
- `--all-day` — mark as all-day event (no value needed)
- `--recurrence daily|weekly|monthly|yearly` — repeat frequency
- `--interval N` — repeat every N periods (default: 1). E.g., `--recurrence weekly --interval 2` = biweekly
- `--recurrence-end 2026-06-30` — stop repeating after this date
- `--recurrence-count 10` — stop after N occurrences
- `--recurrence-days 2,4,6` — specific days of week (1=Sun, 2=Mon, ..., 7=Sat). Only with `--recurrence weekly`

**Recurrence examples:**
```bash
# Daily standup for 2 weeks
... create-event "Standup" <start> <end> <cal_id> --recurrence daily --recurrence-count 10

# Every Monday and Wednesday
... create-event "Gym" <start> <end> <cal_id> --recurrence weekly --recurrence-days 2,4

# Biweekly until end of year
... create-event "1:1" <start> <end> <cal_id> --recurrence weekly --interval 2 --recurrence-end 2026-12-31

# Monthly review
... create-event "Monthly Review" <start> <end> <cal_id> --recurrence monthly
```

**Before creating**: always confirm with the user (show title, time, calendar, recurrence). Ask which calendar if ambiguous.

#### Modify event
```bash
~/.claude/skills/osx-calendar/scripts/calendar-helper modify-event <event_id> [--title X] [--start X] [--end X] [--location X] [--notes X]
```

**Mandatory**: show the current event details and get user confirmation before running this command.

#### Delete event
```bash
~/.claude/skills/osx-calendar/scripts/calendar-helper delete-event <event_id>
```

**Mandatory**: show the event details and get explicit user confirmation before running this command. This is destructive and cannot be undone.

## Timezone handling (Singapore UTC+8)

**CRITICAL**: The user is in Singapore (UTC+8). Always get the real current date first before calculating any relative dates.

### Step 1: Always get today's Singapore date first

Before doing ANY date calculation, run this to get the authoritative current date:

```bash
TZ=Asia/Singapore date +"%Y-%m-%d %A"
```

**This shell output is the ONLY source of truth for today's date and day name.** Do NOT use your training knowledge, memory context, or any assumption about what day it is. The shell command is always correct — your internal knowledge about calendar dates is not reliable.

### Step 2: Calculate target date relative to today

Given today's Singapore date, calculate the user's requested day:

- **"today"** → today's date
- **"tomorrow"** → today + 1 day
- **"Monday" / "Mon"** → find the nearest upcoming Monday (or today if today is Monday)
- **"Tuesday" / "Tue"** → find the nearest upcoming Tuesday
- ... and so on for any day name
- **"next week"** → next Monday through Sunday
- **"this month"** → 1st through last day of current month

**Key rule**: "Monday" means the **next occurrence** of Monday in Singapore. If today is Saturday March 15 (SGT), then Monday = March 16 — the very next day. Do not skip to the following week.

### Step 3: Pass date-only to CLI

Use `YYYY-MM-DD` format. The Swift binary interprets date-only strings as midnight in the system's local timezone (Singapore), so this is safe.

- Single day query: `list-events 2026-03-16 2026-03-17` (start inclusive, end exclusive)
- Week query: `list-events 2026-03-16 2026-03-23`

## Presenting results

When showing events to the user:
- Times in JSON are UTC — convert to Singapore (UTC+8) for display
- Use human-readable format: "10:00 AM – 12:00 PM" not ISO timestamps
- Group by date for multi-day queries
- Show calendar name for context when events span multiple calendars
- For all-day events, show "(All Day)" instead of times
- Truncate long notes — show first line or omit if not relevant

**Example conversion**:
- JSON: `"start": "2026-03-16T02:00:00Z"` (2 AM UTC)
- Display: `10:00 AM` (Singapore time, UTC+8)

## Troubleshooting

| Symptom | Cause | Fix |
|---------|-------|-----|
| Only `VIRTUAL_APP_CALENDAR_UUID` returned | Terminal app lacks Calendar permission | System Settings > Privacy & Security > Calendars > enable terminal app |
| `access_denied` error | Same as above | Same as above |
| Calendar missing from list | Account not configured in macOS Calendar app | Open Calendar.app, add the account |
| `calendar-helper: command not found` | Binary not compiled | Run `swiftc` command from Setup section |
| Events show wrong times | Timezone mismatch | Times are UTC in JSON — convert to local for display |

## Limitations

- No attachment support
- Subscribed calendars are read-only
- Search is limited to title/notes/location text matching
- Recurring events: creation supported (daily/weekly/monthly/yearly), but modifying recurrence rules on existing events is not — modify individual occurrences instead
