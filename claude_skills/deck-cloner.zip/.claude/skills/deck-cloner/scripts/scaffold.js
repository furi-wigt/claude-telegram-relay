#!/usr/bin/env node
/**
 * Deck Cloner — Full Pipeline Scaffold
 * 
 * Claude Code fills in design tokens from design-spec.json, processes
 * markdown via the content classifier, loads Gemini-generated assets,
 * and builds the final deck.
 * 
 * Usage:
 *   1. Run gemini-asset-pipeline.sh first (generates assets/)
 *   2. node generate-deck.js
 * 
 * Output: output.pptx
 */

// ── Load GEMINI_API_KEY from ~/.deck-cloner/.env (user-wide) ──
const os = require("os");
const dotenvPath = require("path").join(os.homedir(), ".deck-cloner", ".env");
try {
  const envContent = require("fs").readFileSync(dotenvPath, "utf8");
  for (const line of envContent.split("\n")) {
    const match = line.match(/^(\w+)=(.+)$/);
    if (match && !process.env[match[1]]) {
      process.env[match[1]] = match[2].trim();
    }
  }
} catch (_) { /* env file not found — key may already be in environment */ }

const pptxgen = require("pptxgenjs");
const React = require("react");
const ReactDOMServer = require("react-dom/server");
const sharp = require("sharp");
const fs = require("fs");
const path = require("path");

// ============================================================
// LOAD DESIGN SPEC + SLIDE PLAN
// ============================================================

const designSpec = JSON.parse(fs.readFileSync("./design-spec.json", "utf8"));
const slidePlan = JSON.parse(fs.readFileSync("./slide-plan.json", "utf8"));

const COLORS = designSpec.palette;
const FONTS = designSpec.typography;
const LAYOUT = designSpec.layout;
const MOTIFS = designSpec.motifs;

// ============================================================
// ASSET LOADER — find all generated images in assets/
// ============================================================

function loadAssets() {
  const assetsDir = "./assets";
  const assets = {};
  if (!fs.existsSync(assetsDir)) return assets;

  for (const file of fs.readdirSync(assetsDir)) {
    if (!/\.(png|jpg|jpeg|svg)$/i.test(file)) continue;
    // Parse filename: slide-N-type.png → key: "slide-N-type"
    const key = file.replace(/\.(png|jpg|jpeg|svg)$/i, "");
    assets[key] = path.join(assetsDir, file);
  }

  console.log(`📦 Loaded ${Object.keys(assets).length} visual assets`);
  return assets;
}

// ============================================================
// HELPER FACTORIES — fresh objects every time
// ============================================================

const makeCardShadow = () => ({ ...MOTIFS.shadowStyle });

function addTitle(slide, text, dark = false) {
  slide.addText(text, {
    x: LAYOUT.margins.left, y: LAYOUT.margins.top,
    w: LAYOUT.contentWidth, h: 0.6,
    fontSize: FONTS.sizes.slideTitle,
    fontFace: FONTS.headingFont,
    color: dark ? COLORS.headingColor : COLORS.bodyColor,
    bold: true, margin: 0,
  });
}

function addCard(slide, pres, x, y, w, h) {
  slide.addShape(pres.shapes.RECTANGLE, {
    x, y, w, h,
    fill: { color: "FFFFFF" },
    shadow: makeCardShadow(),
  });
}

function addAccentBar(slide, pres, x, y, h) {
  slide.addShape(pres.shapes.RECTANGLE, {
    x, y, w: MOTIFS.accentBarWidth, h,
    fill: { color: COLORS.accent1 },
  });
}

function addFooter(slide, num, total) {
  slide.addText(`${num} / ${total}`, {
    x: LAYOUT.margins.left + LAYOUT.contentWidth - 1.5, y: 5.1,
    w: 1.5, h: 0.3,
    fontSize: FONTS.sizes.caption,
    fontFace: FONTS.captionFont,
    color: COLORS.mutedColor, align: "right", margin: 0,
  });
}

// ============================================================
// ICON UTILITIES
// ============================================================

function renderIconSvg(IconComponent, color = "#000000", size = 256) {
  return ReactDOMServer.renderToStaticMarkup(
    React.createElement(IconComponent, { color, size: String(size) })
  );
}

async function iconToBase64Png(IconComponent, color, size = 256) {
  const svg = renderIconSvg(IconComponent, color, size);
  const pngBuffer = await sharp(Buffer.from(svg)).png().toBuffer();
  return "image/png;base64," + pngBuffer.toString("base64");
}

// ============================================================
// SLIDE BUILDERS
// ============================================================

function buildTitleSlide(slide, pres, plan, assets, total) {
  const bg = assets[`slide-${plan.index}-bg`];
  slide.background = bg ? { path: bg } : { color: COLORS.primaryBg };

  slide.addText(plan.heading, {
    x: LAYOUT.margins.left, y: 1.5,
    w: LAYOUT.contentWidth, h: 1.5,
    fontSize: FONTS.sizes.heroTitle, fontFace: FONTS.headingFont,
    color: COLORS.headingColor, bold: true, margin: 0,
  });

  const subtitle = (plan.content || "").split("\n")[0];
  if (subtitle) {
    slide.addText(subtitle, {
      x: LAYOUT.margins.left, y: 3.2,
      w: LAYOUT.contentWidth, h: 0.6,
      fontSize: 18, fontFace: FONTS.bodyFont,
      color: COLORS.mutedColor, margin: 0,
    });
  }
}

function buildSectionDivider(slide, pres, plan, assets, total) {
  const bg = assets[`slide-${plan.index}-bg`];
  slide.background = bg ? { path: bg } : { color: COLORS.primaryBg };

  slide.addText(plan.heading, {
    x: LAYOUT.margins.left, y: 2.0,
    w: LAYOUT.contentWidth, h: 1.2,
    fontSize: 40, fontFace: FONTS.headingFont,
    color: COLORS.headingColor, bold: true, margin: 0, valign: "middle",
  });
}

function buildNarrativeSlide(slide, pres, plan, assets, total) {
  slide.background = { color: COLORS.secondaryBg };
  addTitle(slide, plan.heading);

  const spot = assets[`slide-${plan.index}-spot`];
  const textW = spot ? LAYOUT.contentWidth * 0.55 : LAYOUT.contentWidth;

  slide.addText(plan.content, {
    x: LAYOUT.margins.left, y: 1.4, w: textW, h: 3.5,
    fontSize: FONTS.sizes.body, fontFace: FONTS.bodyFont,
    color: COLORS.bodyColor, valign: "top", margin: 0,
    lineSpacingMultiple: 1.4,
  });

  if (spot) {
    const imgX = LAYOUT.margins.left + textW + LAYOUT.columnGap;
    const imgW = LAYOUT.contentWidth * 0.4;
    slide.addImage({
      path: spot, x: imgX, y: 1.4, w: imgW, h: 3.0,
      sizing: { type: "contain", w: imgW, h: 3.0 },
    });
  }

  addFooter(slide, plan.index, total);
}

function buildKeyPointsSlide(slide, pres, plan, assets, total) {
  slide.background = { color: COLORS.secondaryBg };
  addTitle(slide, plan.heading);

  const items = plan.bullets || [];
  const cols = items.length <= 3 ? items.length : Math.min(3, Math.ceil(items.length / 2));
  const rows = Math.ceil(items.length / cols);
  const CW = LAYOUT.contentWidth;
  const colW = (CW - LAYOUT.columnGap * (cols - 1)) / cols;
  const rowH = rows === 1 ? 3.2 : 1.6;

  items.forEach((item, i) => {
    const col = i % cols;
    const row = Math.floor(i / cols);
    const x = LAYOUT.margins.left + col * (colW + LAYOUT.columnGap);
    const y = 1.4 + row * (rowH + LAYOUT.verticalGap);

    addCard(slide, pres, x, y, colW, rowH);

    const iconAsset = assets[`slide-${plan.index}-icon-${i}`];
    if (iconAsset) {
      slide.addImage({ path: iconAsset, x: x + 0.2, y: y + 0.2, w: 0.4, h: 0.4 });
    } else {
      slide.addShape(pres.shapes.OVAL, {
        x: x + 0.2, y: y + 0.2, w: 0.4, h: 0.4,
        fill: { color: COLORS.accent1, transparency: 85 },
      });
    }

    const tX = x + 0.75;
    const tW = colW - 0.95;
    slide.addText(item.heading, {
      x: tX, y: y + 0.2, w: tW, h: 0.35,
      fontSize: 13, fontFace: FONTS.headingFont,
      color: COLORS.bodyColor, bold: true, margin: 0,
    });
    if (item.body) {
      slide.addText(item.body, {
        x: tX, y: y + 0.55, w: tW, h: rowH - 0.75,
        fontSize: 11, fontFace: FONTS.bodyFont,
        color: COLORS.mutedColor, margin: 0, valign: "top",
      });
    }
  });

  addFooter(slide, plan.index, total);
}

function buildStatSlide(slide, pres, plan, assets, total) {
  slide.background = { color: COLORS.secondaryBg };
  addTitle(slide, plan.heading);

  const stats = (plan.stats || []).slice(0, 4);
  const colW = (LAYOUT.contentWidth - LAYOUT.columnGap * (stats.length - 1)) / stats.length;

  stats.forEach((stat, i) => {
    const x = LAYOUT.margins.left + i * (colW + LAYOUT.columnGap);
    const y = 1.6;
    const h = 2.8;

    addCard(slide, pres, x, y, colW, h);
    addAccentBar(slide, pres, x, y, h);

    slide.addText(stat.value, {
      x: x + 0.3, y: y + 0.4, w: colW - 0.5, h: 1.0,
      fontSize: 48, fontFace: FONTS.headingFont,
      color: COLORS.accent1, bold: true, margin: 0,
    });

    slide.addText(stat.label, {
      x: x + 0.3, y: y + 1.5, w: colW - 0.5, h: 0.5,
      fontSize: 12, fontFace: FONTS.captionFont,
      color: COLORS.mutedColor, margin: 0,
    });

    const sym = stat.trend === "up" ? "↑" : stat.trend === "down" ? "↓" : "—";
    const clr = stat.trend === "up" ? (COLORS.accent2 || "30D158")
              : stat.trend === "down" ? "FF375F"
              : COLORS.mutedColor;
    slide.addText(sym, {
      x: x + colW - 0.6, y: y + 0.4, w: 0.4, h: 0.4,
      fontSize: 20, color: clr, align: "center", margin: 0,
    });
  });

  addFooter(slide, plan.index, total);
}

function buildTableSlide(slide, pres, plan, assets, total) {
  slide.background = { color: COLORS.secondaryBg };
  addTitle(slide, plan.heading);

  const { headers, rows } = plan.tableData || {};
  if (!headers || !rows) return;

  const tableRows = [
    headers.map(h => ({
      text: h, options: {
        bold: true, color: "FFFFFF",
        fill: { color: COLORS.tableHeaderBg || COLORS.primaryBg },
        fontSize: 12, fontFace: FONTS.bodyFont,
        align: "center", valign: "middle",
      }
    })),
    ...rows.map((row, i) => row.map(cell => ({
      text: String(cell), options: {
        fontSize: 11, fontFace: FONTS.bodyFont,
        color: COLORS.bodyColor,
        fill: { color: i % 2 === 0 ? "FFFFFF" : (COLORS.tableStripeBg || COLORS.secondaryBg) },
        valign: "middle",
      }
    })))
  ];

  slide.addTable(tableRows, {
    x: LAYOUT.margins.left, y: 1.4, w: LAYOUT.contentWidth,
    border: { pt: 0.5, color: COLORS.tableBorder || "E5E5EA" },
    colW: headers.map(() => LAYOUT.contentWidth / headers.length),
    rowH: [0.45, ...rows.map(() => 0.4)],
  });

  addFooter(slide, plan.index, total);
}

function buildProcessSlide(slide, pres, plan, assets, total) {
  slide.background = { color: COLORS.secondaryBg };
  addTitle(slide, plan.heading);

  const steps = (plan.steps || []).slice(0, 5);
  const stepW = LAYOUT.contentWidth / steps.length;
  const circleSize = 0.5;
  const y = 2.2;

  steps.forEach((step, i) => {
    const cx = LAYOUT.margins.left + i * stepW + stepW / 2;

    if (i < steps.length - 1) {
      slide.addShape(pres.shapes.LINE, {
        x: cx + circleSize / 2 + 0.05, y: y + circleSize / 2,
        w: stepW - circleSize - 0.1, h: 0,
        line: { color: COLORS.mutedColor, width: 1.5, dashType: "dash" },
      });
    }

    slide.addShape(pres.shapes.OVAL, {
      x: cx - circleSize / 2, y, w: circleSize, h: circleSize,
      fill: { color: COLORS.accent1 },
    });
    slide.addText(String(i + 1), {
      x: cx - circleSize / 2, y, w: circleSize, h: circleSize,
      fontSize: 16, fontFace: FONTS.headingFont,
      color: "FFFFFF", bold: true, align: "center", valign: "middle", margin: 0,
    });

    slide.addText(step, {
      x: cx - stepW * 0.4, y: y + circleSize + 0.3,
      w: stepW * 0.8, h: 1.5,
      fontSize: 11, fontFace: FONTS.bodyFont,
      color: COLORS.bodyColor, align: "center", valign: "top", margin: 0,
    });
  });

  addFooter(slide, plan.index, total);
}

function buildQuoteSlide(slide, pres, plan, assets, total) {
  slide.background = { color: COLORS.secondaryBg };

  const lines = (plan.content || "").split("\n");
  const quoteText = lines.filter(l => l.startsWith(">")).map(l => l.replace(/^>\s*/, "")).join(" ");
  const attrib = lines.find(l => !l.startsWith(">") && l.trim()) || "";

  slide.addShape(pres.shapes.RECTANGLE, {
    x: LAYOUT.margins.left, y: 1.5, w: 0.08, h: 2.5,
    fill: { color: COLORS.accent1 },
  });

  slide.addText(`"${quoteText}"`, {
    x: LAYOUT.margins.left + 0.4, y: 1.5,
    w: LAYOUT.contentWidth - 0.4, h: 2.0,
    fontSize: 22, fontFace: FONTS.headingFont,
    color: COLORS.bodyColor, italic: true, valign: "middle",
    margin: 0, lineSpacingMultiple: 1.4,
  });

  if (attrib) {
    slide.addText(attrib.replace(/^[-—–]\s*/, "— "), {
      x: LAYOUT.margins.left + 0.4, y: 3.6,
      w: LAYOUT.contentWidth - 0.4, h: 0.4,
      fontSize: 14, fontFace: FONTS.captionFont,
      color: COLORS.mutedColor, margin: 0,
    });
  }
}

function buildTechnicalSlide(slide, pres, plan, assets, total) {
  slide.background = { color: COLORS.secondaryBg };
  addTitle(slide, plan.heading);

  const codeMatch = (plan.content || "").match(/```(?:\w+)?\n([\s\S]*?)```/);
  const code = codeMatch ? codeMatch[1].trim() : plan.content;

  slide.addShape(pres.shapes.RECTANGLE, {
    x: LAYOUT.margins.left, y: 1.4,
    w: LAYOUT.contentWidth, h: 3.5,
    fill: { color: "1E1E1E" },
    shadow: { type: "outer", blur: 8, offset: 3, color: "000000", opacity: 0.2, angle: 135 },
  });

  slide.addText(code, {
    x: LAYOUT.margins.left + 0.3, y: 1.6,
    w: LAYOUT.contentWidth - 0.6, h: 3.1,
    fontSize: 11, fontFace: "Consolas",
    color: "D4D4D4", valign: "top", margin: 0, lineSpacingMultiple: 1.3,
  });

  addFooter(slide, plan.index, total);
}

function buildClosingSlide(slide, pres, plan, assets, total) {
  const bg = assets[`slide-${plan.index}-bg`];
  slide.background = bg ? { path: bg } : { color: COLORS.primaryBg };

  slide.addText(plan.heading || "Thank You", {
    x: LAYOUT.margins.left, y: 1.8,
    w: LAYOUT.contentWidth, h: 1.2,
    fontSize: 40, fontFace: FONTS.headingFont,
    color: COLORS.headingColor, bold: true, align: "center", margin: 0,
  });

  const contact = (plan.content || "").replace(/^[\s>*-]+/gm, "").trim();
  if (contact) {
    slide.addText(contact, {
      x: LAYOUT.margins.left + LAYOUT.contentWidth * 0.2, y: 3.3,
      w: LAYOUT.contentWidth * 0.6, h: 1.0,
      fontSize: 14, fontFace: FONTS.bodyFont,
      color: COLORS.mutedColor, align: "center", margin: 0,
    });
  }
}

// ============================================================
// ROUTER
// ============================================================

const BUILDERS = {
  "title-slide": buildTitleSlide,
  "section-divider": buildSectionDivider,
  "narrative": buildNarrativeSlide,
  "key-points": buildKeyPointsSlide,
  "detailed-list": buildKeyPointsSlide,
  "stat-callout": buildStatSlide,
  "data-table": buildTableSlide,
  "process-flow": buildProcessSlide,
  "quote": buildQuoteSlide,
  "technical": buildTechnicalSlide,
  "closing": buildClosingSlide,
};

// ============================================================
// MAIN
// ============================================================

async function main() {
  const assets = loadAssets();
  const pres = new pptxgen();
  pres.layout = designSpec.meta.layout || "LAYOUT_16x9";
  pres.author = "Deck Cloner";
  pres.title = slidePlan.slides[0]?.heading || "Presentation";

  const total = slidePlan.totalSlides;

  for (const plan of slidePlan.slides) {
    const slide = pres.addSlide();
    const builder = BUILDERS[plan.type] || buildNarrativeSlide;
    console.log(`📝 Slide ${plan.index}/${total}: ${plan.type} — "${plan.heading}"`);
    await builder(slide, pres, plan, assets, total);
  }

  const outPath = "output.pptx";
  await pres.writeFile({ fileName: outPath });
  console.log(`\n✅ Created: ${outPath} (${total} slides)`);
}

main().catch((err) => {
  console.error("❌ Error:", err);
  process.exit(1);
});