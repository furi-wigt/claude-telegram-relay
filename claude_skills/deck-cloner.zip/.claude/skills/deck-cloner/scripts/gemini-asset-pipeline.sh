#!/bin/bash
# Deck Cloner — Gemini CLI Asset Pipeline
# Generates all visual assets needed by the slide plan.
#
# Prerequisites:
#   - gemini CLI installed and authenticated
#   - design-spec.json and slide-plan.json in current directory
#   - jq installed (for JSON parsing)
#
# Usage: bash scripts/gemini-asset-pipeline.sh
#
# Assets are saved to ./assets/ and named: slide-N-{bg|spot|icon-I}.png

set -euo pipefail

# ── Load GEMINI_API_KEY from user-wide config ──
ENV_FILE="$HOME/.deck-cloner/.env"
if [ -z "${GEMINI_API_KEY:-}" ]; then
  if [ -f "$ENV_FILE" ]; then
    set -a; source "$ENV_FILE"; set +a
    echo "🔑 Loaded API key from $ENV_FILE"
  else
    echo "❌ GEMINI_API_KEY not set and $ENV_FILE not found."
    echo "   Run: bash scripts/setup-env.sh"
    exit 1
  fi
fi

ASSETS_DIR="./assets"
mkdir -p "$ASSETS_DIR"

PLAN="slide-plan.json"
SPEC="design-spec.json"

# Validate inputs
if [ ! -f "$PLAN" ]; then echo "❌ Missing $PLAN"; exit 1; fi
if [ ! -f "$SPEC" ]; then echo "❌ Missing $SPEC"; exit 1; fi
if ! command -v gemini &>/dev/null; then echo "❌ gemini CLI not found. Install: npm install -g @google/gemini-cli"; exit 1; fi
if ! command -v jq &>/dev/null; then echo "❌ jq not found. Install: apt-get install jq / brew install jq"; exit 1; fi

# Extract design tokens
ACCENT1=$(jq -r '.palette.accent1' "$SPEC")
ACCENT2=$(jq -r '.palette.accent2' "$SPEC")
PRIMARY_BG=$(jq -r '.palette.primaryBg' "$SPEC")
SECONDARY_BG=$(jq -r '.palette.secondaryBg' "$SPEC")
BODY_COLOR=$(jq -r '.palette.bodyColor' "$SPEC")
ILLUST_STYLE=$(jq -r '.motifs.illustrationStyle' "$SPEC")

STYLE_BLOCK="STYLE RULES (mandatory): Use ONLY these colors: #${ACCENT1} (primary), #${ACCENT2} (secondary), #${PRIMARY_BG} (dark bg), #${SECONDARY_BG} (light bg). Illustration style: ${ILLUST_STYLE}. No text, no labels, no watermarks. Clean, professional, presentation-ready."

# ── Model fallback chain for 500/503 resilience ──
# Nano Banana 2 is in Preview and often returns 500/503 during peak hours.
# Strategy: try NB2 → NB Pro → NB original, with exponential backoff.
MODELS=("gemini-3.1-flash-image-preview" "gemini-3-pro-image-preview" "gemini-2.5-flash-image")
RETRY_DELAYS=(0 5 15)

generate_with_fallback() {
  local PROMPT="$1"
  local OUTPUT="$2"

  for model in "${MODELS[@]}"; do
    for attempt in 0 1 2; do
      [ "${RETRY_DELAYS[$attempt]}" -gt 0 ] && {
        echo "   ⏳ Backoff ${RETRY_DELAYS[$attempt]}s before retry..."
        sleep "${RETRY_DELAYS[$attempt]}"
      }

      if timeout 120 gemini -p "Using model ${model}: ${PROMPT}" --yolo 2>/dev/null; then
        local FSIZE
        FSIZE=$(stat -c%s "$OUTPUT" 2>/dev/null || stat -f%z "$OUTPUT" 2>/dev/null || echo "0")
        if [ -f "$OUTPUT" ] && [ "$FSIZE" -gt 1000 ]; then
          echo "   ✅ Generated with ${model} (attempt $((attempt+1)))"
          return 0
        fi
      fi
      echo "   ⚠️  ${model} attempt $((attempt+1)) failed (500/503 or timeout)"
    done
    echo "   ↩️  Falling back from ${model}..."
  done

  echo "   ❌ All models failed for this asset"
  return 1
}

echo "🎨 Deck Cloner Asset Pipeline"
echo "   Style: $ILLUST_STYLE"
echo "   Colors: #$ACCENT1, #$ACCENT2, #$PRIMARY_BG"
echo "   Model chain: ${MODELS[*]}"
echo ""

SLIDE_COUNT=$(jq '.slides | length' "$PLAN")
GENERATED=0
SKIPPED=0
FAILED=0

for ((i=0; i<SLIDE_COUNT; i++)); do
  SLIDE_TYPE=$(jq -r ".slides[$i].type" "$PLAN")
  SLIDE_IDX=$(jq -r ".slides[$i].index" "$PLAN")
  VISUAL_TYPE=$(jq -r ".slides[$i].visualNeeds.type" "$PLAN")
  HEADING=$(jq -r ".slides[$i].heading" "$PLAN")
  DESCRIPTION=$(jq -r ".slides[$i].visualNeeds.description // empty" "$PLAN")

  # Skip slides with no visual needs
  if [ "$VISUAL_TYPE" = "none" ] || [ "$VISUAL_TYPE" = "null" ] || [ "$VISUAL_TYPE" = "trend-icons" ]; then
    echo "⏭️  Slide $SLIDE_IDX ($SLIDE_TYPE): Skipping — $VISUAL_TYPE"
    ((SKIPPED++))
    continue
  fi

  # Skip per-item-icons if using react-icons
  USE_REACT_ICONS=$(jq -r ".slides[$i].visualNeeds.useReactIcons // false" "$PLAN")
  if [ "$VISUAL_TYPE" = "per-item-icons" ] && [ "$USE_REACT_ICONS" = "true" ]; then
    echo "⏭️  Slide $SLIDE_IDX ($SLIDE_TYPE): Using react-icons instead of Gemini"
    ((SKIPPED++))
    continue
  fi

  echo ""
  echo "🖼️  Slide $SLIDE_IDX ($SLIDE_TYPE): Generating $VISUAL_TYPE..."

  case "$VISUAL_TYPE" in

    "background-illustration"|"abstract-background")
      OUTPUT="$ASSETS_DIR/slide-${SLIDE_IDX}-bg.png"
      if [ -f "$OUTPUT" ]; then
        echo "   Already exists, skipping"
        ((SKIPPED++))
        continue
      fi

      PROMPT="Generate an image. ${STYLE_BLOCK} Background: solid #${PRIMARY_BG}. Aspect ratio 16:9, resolution 1920x1080. SUBJECT: A subtle ${ILLUST_STYLE} illustration representing '${HEADING}'. ${DESCRIPTION:-Keep the center area clear for text overlay. Heavier detail on edges and corners.} Save the generated image to ${OUTPUT}"

      if generate_with_fallback "$PROMPT" "$OUTPUT"; then
        ((GENERATED++))
      else
        ((FAILED++))
      fi
      ;;

    "spot-illustration")
      OUTPUT="$ASSETS_DIR/slide-${SLIDE_IDX}-spot.png"
      if [ -f "$OUTPUT" ]; then
        echo "   Already exists, skipping"
        ((SKIPPED++))
        continue
      fi

      PROMPT="Generate an image. ${STYLE_BLOCK} Background: white (#FFFFFF). Aspect ratio 1:1, resolution 512x512. SUBJECT: A ${ILLUST_STYLE} illustration of '${HEADING}'. ${DESCRIPTION:-Single focused subject, centered composition.} Save the generated image to ${OUTPUT}"

      if generate_with_fallback "$PROMPT" "$OUTPUT"; then
        ((GENERATED++))
      else
        ((FAILED++))
      fi
      ;;

    "per-item-icons")
      BULLET_COUNT=$(jq ".slides[$i].bullets | length" "$PLAN" 2>/dev/null || echo "0")
      for ((j=0; j<BULLET_COUNT; j++)); do
        BULLET_HEADING=$(jq -r ".slides[$i].bullets[$j].heading" "$PLAN")
        OUTPUT="$ASSETS_DIR/slide-${SLIDE_IDX}-icon-${j}.png"

        if [ -f "$OUTPUT" ]; then
          echo "   Icon $j already exists, skipping"
          continue
        fi

        PROMPT="Generate an image. ${STYLE_BLOCK} Background: white. Resolution 256x256, square. SUBJECT: A single icon representing '${BULLET_HEADING}' in ${ILLUST_STYLE} style. Simple, bold, recognizable at small sizes. Save to ${OUTPUT}"

        if generate_with_fallback "$PROMPT" "$OUTPUT"; then
          ((GENERATED++))
        else
          ((FAILED++))
        fi
      done
      ;;

    *)
      echo "   ⏭️  Unknown visual type: $VISUAL_TYPE"
      ((SKIPPED++))
      ;;
  esac
done

echo ""
echo "════════════════════════════════"
echo "📊 Asset Pipeline Summary"
echo "   Generated: $GENERATED"
echo "   Skipped:   $SKIPPED"
echo "   Failed:    $FAILED"
echo ""

if [ "$GENERATED" -gt 0 ] || [ -d "$ASSETS_DIR" ]; then
  echo "📁 Assets directory:"
  ls -la "$ASSETS_DIR/" 2>/dev/null || echo "   (empty)"
fi

if [ "$FAILED" -gt 0 ]; then
  echo ""
  echo "⚠️  $FAILED assets failed. The PptxGenJS script will use"
  echo "   fallback visuals (solid colors, gradient backgrounds,"
  echo "   or react-icons) for missing assets."
fi

echo ""
echo "✅ Next step: node generate-deck.js"