#!/usr/bin/env python3
"""
Deck Cloner — PPTX Pre-Processor

When a .pptx reference file is provided instead of screenshots, this script:
1. Converts all slides to images (for vision analysis + QA comparison)
2. Extracts design tokens programmatically from the XML (colors, fonts, sizes, layouts)
3. Outputs a partial design-spec.json that Claude Code merges with vision analysis

This MUST run before any other processing to prevent the generic pptx editing
skill from hijacking the workflow.

Usage:
    python scripts/pptx-preprocess.py reference.pptx [output_dir]

Output:
    {output_dir}/
    ├── reference-slides/     # Slide images for vision analysis
    │   ├── slide-01.jpg
    │   ├── slide-02.jpg
    │   └── ...
    ├── unpacked/             # Raw XML for programmatic extraction
    │   └── ppt/
    │       ├── presentation.xml
    │       ├── slides/
    │       ├── slideLayouts/
    │       ├── slideMasters/
    │       └── theme/
    └── extracted-tokens.json  # Programmatically extracted design tokens
"""

import json
import os
import re
import subprocess
import sys
from pathlib import Path

try:
    import defusedxml.minidom as minidom
except ImportError:
    from xml.dom import minidom


# ──────────────────────────────────────────────
# EMU / Point conversion constants
# ──────────────────────────────────────────────
EMU_PER_INCH = 914400
EMU_PER_PT = 12700
EMU_PER_CM = 360000


def emu_to_inches(emu):
    """Convert EMU to inches."""
    return round(int(emu) / EMU_PER_INCH, 3)


def emu_to_pt(emu):
    """Convert EMU to points."""
    return round(int(emu) / EMU_PER_PT, 1)


def hundredths_to_pt(val):
    """Convert hundredths of a point (used in font sizes) to points."""
    return round(int(val) / 100, 1)


# ──────────────────────────────────────────────
# Color extraction helpers
# ──────────────────────────────────────────────

def parse_color_from_element(elem):
    """Extract hex color from an XML element (handles srgbClr, schemeClr)."""
    for child in elem.childNodes:
        if child.nodeType != child.ELEMENT_NODE:
            continue
        tag = child.localName

        if tag == "srgbClr":
            return child.getAttribute("val")
        elif tag == "schemeClr":
            # Return scheme name — will be resolved against theme
            return f"scheme:{child.getAttribute('val')}"

    return None


def extract_theme_colors(theme_path):
    """Extract color scheme from theme XML (ppt/theme/theme1.xml)."""
    colors = {}
    try:
        doc = minidom.parse(str(theme_path))

        # Color scheme
        for scheme in doc.getElementsByTagNameNS("*", "clrScheme"):
            for child in scheme.childNodes:
                if child.nodeType != child.ELEMENT_NODE:
                    continue
                name = child.localName  # dk1, dk2, lt1, lt2, accent1-6, hlink, folHlink
                color = parse_color_from_element(child)
                if color and not color.startswith("scheme:"):
                    colors[name] = color

        # Font scheme
        for major in doc.getElementsByTagNameNS("*", "majorFont"):
            for latin in major.getElementsByTagNameNS("*", "latin"):
                colors["majorFont"] = latin.getAttribute("typeface")
        for minor in doc.getElementsByTagNameNS("*", "minorFont"):
            for latin in minor.getElementsByTagNameNS("*", "latin"):
                colors["minorFont"] = latin.getAttribute("typeface")

    except Exception as e:
        print(f"  ⚠️  Theme parse error: {e}")

    return colors


def resolve_scheme_color(scheme_name, theme_colors):
    """Resolve a scheme color name to hex using the theme."""
    mapping = {
        "tx1": "dk1", "tx2": "dk2",
        "bg1": "lt1", "bg2": "lt2",
    }
    key = mapping.get(scheme_name, scheme_name)
    return theme_colors.get(key)


# ──────────────────────────────────────────────
# Slide XML analysis
# ──────────────────────────────────────────────

def extract_slide_tokens(slide_path, theme_colors):
    """Extract design tokens from a single slide XML file."""
    tokens = {
        "colors": set(),
        "font_sizes": [],
        "fonts": set(),
        "bold_count": 0,
        "total_text_runs": 0,
    }

    try:
        doc = minidom.parse(str(slide_path))

        # Background
        for bg in doc.getElementsByTagNameNS("*", "bg"):
            for fill in bg.getElementsByTagNameNS("*", "solidFill"):
                color = parse_color_from_element(fill)
                if color:
                    if color.startswith("scheme:"):
                        resolved = resolve_scheme_color(color[7:], theme_colors)
                        if resolved:
                            tokens["colors"].add(resolved)
                    else:
                        tokens["colors"].add(color)

        # Text runs
        for rpr in doc.getElementsByTagNameNS("*", "rPr"):
            tokens["total_text_runs"] += 1

            # Font size
            sz = rpr.getAttribute("sz")
            if sz:
                tokens["font_sizes"].append(hundredths_to_pt(sz))

            # Bold
            if rpr.getAttribute("b") == "1":
                tokens["bold_count"] += 1

            # Font face
            for latin in rpr.getElementsByTagNameNS("*", "latin"):
                face = latin.getAttribute("typeface")
                if face and face != "+mj-lt" and face != "+mn-lt":
                    tokens["fonts"].add(face)

            # Text color
            for fill in rpr.getElementsByTagNameNS("*", "solidFill"):
                color = parse_color_from_element(fill)
                if color:
                    if color.startswith("scheme:"):
                        resolved = resolve_scheme_color(color[7:], theme_colors)
                        if resolved:
                            tokens["colors"].add(resolved)
                    else:
                        tokens["colors"].add(color)

        # Shape fills
        for sp_pr in doc.getElementsByTagNameNS("*", "spPr"):
            for fill in sp_pr.getElementsByTagNameNS("*", "solidFill"):
                color = parse_color_from_element(fill)
                if color and not color.startswith("scheme:"):
                    tokens["colors"].add(color)

        # Positions and sizes (for layout analysis)
        for off in doc.getElementsByTagNameNS("*", "off"):
            x = off.getAttribute("x")
            y = off.getAttribute("y")
            if x and y:
                tokens.setdefault("positions", []).append({
                    "x": emu_to_inches(x),
                    "y": emu_to_inches(y),
                })

    except Exception as e:
        print(f"  ⚠️  Slide parse error ({slide_path.name}): {e}")

    # Convert sets to lists for JSON
    tokens["colors"] = list(tokens["colors"])
    tokens["fonts"] = list(tokens["fonts"])

    return tokens


def extract_slide_dimensions(presentation_path):
    """Extract slide width/height from presentation.xml."""
    try:
        doc = minidom.parse(str(presentation_path))
        for sz in doc.getElementsByTagNameNS("*", "sldSz"):
            cx = sz.getAttribute("cx")
            cy = sz.getAttribute("cy")
            if cx and cy:
                w = emu_to_inches(cx)
                h = emu_to_inches(cy)
                # Detect layout
                ratio = round(w / h, 2)
                if ratio >= 1.7:
                    layout = "LAYOUT_16x9"
                elif ratio >= 1.5:
                    layout = "LAYOUT_16x10"
                else:
                    layout = "LAYOUT_4x3"
                return {"width": w, "height": h, "layout": layout}
    except Exception:
        pass
    return {"width": 10, "height": 5.625, "layout": "LAYOUT_16x9"}


# ──────────────────────────────────────────────
# Aggregate analysis
# ──────────────────────────────────────────────

def aggregate_tokens(all_slide_tokens, theme_colors, dimensions):
    """Combine per-slide tokens into a unified design spec."""

    # Collect all unique colors, fonts, sizes
    all_colors = set()
    all_fonts = set()
    all_sizes = []

    for st in all_slide_tokens:
        all_colors.update(st["colors"])
        all_fonts.update(st["fonts"])
        all_sizes.extend(st["font_sizes"])

    # Resolve theme fonts
    heading_font = theme_colors.get("majorFont", "")
    body_font = theme_colors.get("minorFont", "")

    # If theme fonts are generic (+mj-lt), use extracted fonts
    if not heading_font or heading_font.startswith("+"):
        heading_font = list(all_fonts)[0] if all_fonts else "Calibri"
    if not body_font or body_font.startswith("+"):
        body_font = list(all_fonts)[-1] if len(all_fonts) > 1 else heading_font

    # Sort font sizes to identify hierarchy
    size_counts = {}
    for s in all_sizes:
        size_counts[s] = size_counts.get(s, 0) + 1

    sorted_sizes = sorted(size_counts.keys(), reverse=True)

    # Map to hierarchy
    sizes = {
        "heroTitle": sorted_sizes[0] if len(sorted_sizes) > 0 else 44,
        "slideTitle": sorted_sizes[1] if len(sorted_sizes) > 1 else 32,
        "sectionHeader": sorted_sizes[2] if len(sorted_sizes) > 2 else 24,
        "body": sorted_sizes[3] if len(sorted_sizes) > 3 else 14,
        "caption": sorted_sizes[-1] if len(sorted_sizes) > 4 else 10,
    }

    # Categorize colors by usage frequency and luminance
    color_list = list(all_colors)

    # Theme color mapping
    palette = {
        "primaryBg": theme_colors.get("dk1", color_list[0] if color_list else "1A1A2E"),
        "secondaryBg": theme_colors.get("lt1", "F5F5F7"),
        "headingColor": theme_colors.get("lt1", "FFFFFF"),
        "bodyColor": theme_colors.get("dk1", "333333"),
        "mutedColor": theme_colors.get("dk2", "8E8E93"),
        "accent1": theme_colors.get("accent1", "0A84FF"),
        "accent2": theme_colors.get("accent2", "30D158"),
        "allExtractedColors": color_list,
        "chartColors": [
            theme_colors.get(f"accent{i}", "") for i in range(1, 7) if theme_colors.get(f"accent{i}")
        ],
    }

    # Estimate margins from position data
    all_x = []
    all_y = []
    for st in all_slide_tokens:
        for pos in st.get("positions", []):
            all_x.append(pos["x"])
            all_y.append(pos["y"])

    margins = {
        "left": round(min(all_x), 2) if all_x else 0.7,
        "top": round(min(all_y), 2) if all_y else 0.6,
        "right": round(dimensions["width"] - max(all_x), 2) if all_x else 0.7,
        "bottom": round(dimensions["height"] - max(all_y), 2) if all_y else 0.5,
    }

    content_width = round(dimensions["width"] - margins["left"] - margins["right"], 2)

    return {
        "meta": {
            "layout": dimensions["layout"],
            "slideCount": len(all_slide_tokens),
            "designStyle": "Extracted from .pptx — refine with vision analysis",
            "source": "pptx-preprocess",
        },
        "palette": palette,
        "typography": {
            "headingFont": heading_font,
            "bodyFont": body_font,
            "captionFont": body_font,
            "sizes": sizes,
        },
        "layout": {
            "margins": margins,
            "contentWidth": content_width,
            "columnGap": 0.4,
            "verticalGap": 0.3,
        },
        "motifs": {
            "cornerRadius": 0.1,
            "iconStyle": "unknown — determine from slide images",
            "iconSize": 0.4,
            "accentBarWidth": 0.06,
            "dividerStyle": "unknown — determine from slide images",
            "shadowStyle": {
                "type": "outer", "blur": 6, "offset": 2,
                "color": "000000", "opacity": 0.12
            },
            "illustrationStyle": "unknown — determine from slide images",
        },
        "_raw": {
            "allFonts": list(all_fonts),
            "allFontSizes": dict(size_counts),
            "themeColors": {k: v for k, v in theme_colors.items() if not k.endswith("Font")},
        },
    }


# ──────────────────────────────────────────────
# Main pipeline
# ──────────────────────────────────────────────

def main():
    if len(sys.argv) < 2:
        print("Usage: python pptx-preprocess.py <reference.pptx> [output_dir]")
        sys.exit(1)

    pptx_path = Path(sys.argv[1])
    output_dir = Path(sys.argv[2]) if len(sys.argv) > 2 else Path(".")

    if not pptx_path.exists():
        print(f"❌ File not found: {pptx_path}")
        sys.exit(1)

    ref_slides_dir = output_dir / "reference-slides"
    unpacked_dir = output_dir / "unpacked"

    ref_slides_dir.mkdir(parents=True, exist_ok=True)

    print("=" * 50)
    print("🔧 Deck Cloner — PPTX Pre-Processor")
    print("=" * 50)
    print(f"   Input:  {pptx_path}")
    print(f"   Output: {output_dir}")
    print()

    # ── Step 1: Convert slides to images ──
    print("📸 Step 1: Converting slides to images...")

    soffice_script = Path("/mnt/skills/public/pptx/scripts/office/soffice.py")
    if soffice_script.exists():
        subprocess.run([
            "python", str(soffice_script),
            "--headless", "--convert-to", "pdf", str(pptx_path)
        ], check=True, capture_output=True)
    else:
        subprocess.run([
            "soffice", "--headless", "--convert-to", "pdf", str(pptx_path)
        ], check=True, capture_output=True)

    pdf_path = pptx_path.with_suffix(".pdf")
    if not pdf_path.exists():
        # soffice may output to current dir
        alt_pdf = Path(pptx_path.stem + ".pdf")
        if alt_pdf.exists():
            pdf_path = alt_pdf

    if pdf_path.exists():
        # Clear old images
        for old in ref_slides_dir.glob("slide-*.jpg"):
            old.unlink()

        subprocess.run([
            "pdftoppm", "-jpeg", "-r", "200",
            str(pdf_path), str(ref_slides_dir / "slide")
        ], check=True, capture_output=True)

        slide_images = sorted(ref_slides_dir.glob("slide-*.jpg"))
        print(f"   ✅ Generated {len(slide_images)} slide images")
        for img in slide_images:
            print(f"      {img.name}")
    else:
        print("   ⚠️  PDF conversion failed — slide images not generated")
        slide_images = []

    print()

    # ── Step 2: Unpack XML ──
    print("📦 Step 2: Unpacking PPTX XML...")

    unpack_script = Path("/mnt/skills/public/pptx/scripts/office/unpack.py")
    if unpack_script.exists():
        result = subprocess.run(
            ["python", str(unpack_script), str(pptx_path), str(unpacked_dir)],
            capture_output=True, text=True
        )
        print(f"   {result.stdout.strip()}")
    else:
        import zipfile
        unpacked_dir.mkdir(parents=True, exist_ok=True)
        with zipfile.ZipFile(pptx_path, "r") as zf:
            zf.extractall(unpacked_dir)
        print(f"   Unpacked to {unpacked_dir}")

    print()

    # ── Step 3: Extract design tokens from XML ──
    print("🎨 Step 3: Extracting design tokens from XML...")

    # Find theme file
    theme_dir = unpacked_dir / "ppt" / "theme"
    theme_colors = {}
    if theme_dir.exists():
        for theme_file in theme_dir.glob("theme*.xml"):
            theme_colors = extract_theme_colors(theme_file)
            print(f"   Theme: {theme_file.name}")
            print(f"   Colors: {len([k for k in theme_colors if not k.endswith('Font')])} scheme colors")
            print(f"   Fonts: major={theme_colors.get('majorFont', '?')}, minor={theme_colors.get('minorFont', '?')}")
            break

    # Extract slide dimensions
    pres_xml = unpacked_dir / "ppt" / "presentation.xml"
    dimensions = extract_slide_dimensions(pres_xml) if pres_xml.exists() else {
        "width": 10, "height": 5.625, "layout": "LAYOUT_16x9"
    }
    print(f"   Dimensions: {dimensions['width']}\" × {dimensions['height']}\" ({dimensions['layout']})")

    # Process each slide
    slides_dir = unpacked_dir / "ppt" / "slides"
    all_slide_tokens = []

    if slides_dir.exists():
        slide_files = sorted(slides_dir.glob("slide*.xml"),
                             key=lambda p: int(re.search(r'(\d+)', p.stem).group(1)))
        for sf in slide_files:
            tokens = extract_slide_tokens(sf, theme_colors)
            all_slide_tokens.append(tokens)
            print(f"   {sf.name}: {len(tokens['colors'])} colors, "
                  f"{len(tokens['font_sizes'])} text runs, "
                  f"{len(tokens['fonts'])} fonts")

    print()

    # ── Step 4: Aggregate and save ──
    print("📋 Step 4: Aggregating design tokens...")

    extracted = aggregate_tokens(all_slide_tokens, theme_colors, dimensions)

    tokens_path = output_dir / "extracted-tokens.json"
    with open(tokens_path, "w") as f:
        json.dump(extracted, f, indent=2)

    print(f"   ✅ Saved: {tokens_path}")
    print()

    # ── Summary ──
    print("=" * 50)
    print("✅ Pre-processing complete!")
    print()
    print("What was extracted programmatically:")
    print(f"   • Theme colors: {json.dumps({k: v for k, v in theme_colors.items() if not k.endswith('Font')}, indent=None)[:80]}...")
    print(f"   • Heading font: {extracted['typography']['headingFont']}")
    print(f"   • Body font: {extracted['typography']['bodyFont']}")
    print(f"   • Font sizes: {extracted['typography']['sizes']}")
    print(f"   • Layout: {extracted['meta']['layout']}")
    print(f"   • Margins: L={extracted['layout']['margins']['left']}\" T={extracted['layout']['margins']['top']}\"")
    print()
    print("What still needs vision analysis (from slide images):")
    print("   • illustrationStyle (flat vector? isometric? photographic?)")
    print("   • iconStyle (filled? outline? in circles?)")
    print("   • dividerStyle (lines? shapes? whitespace?)")
    print("   • Shadow depth and corner radius")
    print("   • Color role assignments (which accent is primary vs secondary)")
    print()
    print("Next steps for Claude Code:")
    print(f"   1. Analyze images in {ref_slides_dir}/ with vision")
    print(f"   2. Merge vision analysis with {tokens_path}")
    print(f"   3. Produce final design-spec.json")
    print(f"   4. Continue with content classification → Gemini assets → build")


if __name__ == "__main__":
    main()
