#!/bin/bash
# Deck Cloner — API Key Setup
#
# Stores GEMINI_API_KEY in ~/.deck-cloner/.env (user-wide, not per-project).
# All deck-cloner scripts load from this location automatically.
#
# Usage:
#   bash scripts/setup-env.sh              # interactive prompt
#   bash scripts/setup-env.sh YOUR_KEY     # direct

set -euo pipefail

ENV_DIR="$HOME/.deck-cloner"
ENV_FILE="$ENV_DIR/.env"

mkdir -p "$ENV_DIR"
chmod 700 "$ENV_DIR"

# Get key from argument or prompt
if [ -n "${1:-}" ]; then
  API_KEY="$1"
else
  echo "🔑 Deck Cloner — Gemini API Key Setup"
  echo ""
  echo "This stores your GEMINI_API_KEY at: $ENV_FILE"
  echo "Get a key from: https://aistudio.google.com/apikey"
  echo ""
  read -rsp "Paste your GEMINI_API_KEY: " API_KEY
  echo ""
fi

if [ -z "$API_KEY" ]; then
  echo "❌ No key provided. Aborting."
  exit 1
fi

# Write (overwrite if exists)
cat > "$ENV_FILE" <<EOF
# Deck Cloner — Gemini API Key
# Used by Nano Banana 2 (gemini-3.1-flash-image-preview) for image generation
# Get or rotate your key at: https://aistudio.google.com/apikey
GEMINI_API_KEY=${API_KEY}
EOF

chmod 600 "$ENV_FILE"

echo "✅ Saved to $ENV_FILE"
echo "   Permissions: $(ls -la "$ENV_FILE" | awk '{print $1}')"
echo ""
echo "To verify: source $ENV_FILE && echo \$GEMINI_API_KEY"