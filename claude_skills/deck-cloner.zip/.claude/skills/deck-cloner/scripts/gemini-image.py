#!/usr/bin/env python3
"""
Gemini image generation / vision analysis for deck-cloner.

Usage:
  # Generate image (exits 0 on success, 1 on failure)
  uv run --with google-genai scripts/gemini-image.py "PROMPT" ./assets/slide-1-bg.png

  # Vision analysis — outputs text/JSON to stdout
  uv run --with google-genai scripts/gemini-image.py "PROMPT" --vision-file ./ref.png

  # Force a specific model
  uv run --with google-genai scripts/gemini-image.py "PROMPT" output.png --model gemini-3-pro-image-preview

Requires: GEMINI_API_KEY env var
"""

import sys
import os
import time
import base64
import argparse
from pathlib import Path

# Model fallback chain: fast preview → pro → stable
MODELS = [
    "gemini-3.1-flash-image-preview",   # Nano Banana 2 — fast, 4K capable
    "gemini-3-pro-image-preview",        # Nano Banana Pro — more reliable
    "gemini-2.5-flash-image",            # Stable last-resort fallback
]
RETRY_DELAYS = [0, 5, 15]  # seconds between attempts per model


def generate_image(prompt: str, output_path: str, model: str) -> bool:
    from google import genai
    from google.genai import types

    client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])
    print(f"  [gemini] model={model}  output={output_path}", flush=True)

    response = client.models.generate_content(
        model=model,
        contents=[prompt],
        config=types.GenerateContentConfig(
            response_modalities=["Image", "Text"],
        ),
    )

    for part in response.candidates[0].content.parts:
        if part.inline_data:
            Path(output_path).parent.mkdir(parents=True, exist_ok=True)
            data = part.inline_data.data
            image_bytes = base64.b64decode(data) if isinstance(data, str) else data
            with open(output_path, "wb") as f:
                f.write(image_bytes)
            size = Path(output_path).stat().st_size
            print(f"  [gemini] saved {size:,} bytes → {output_path}", flush=True)
            return size > 1000

    print("  [gemini] no image part in response", flush=True)
    return False


def analyze_image(prompt: str, vision_file: str) -> str:
    from google import genai
    from google.genai import types

    client = genai.Client(api_key=os.environ["GEMINI_API_KEY"])
    model = "gemini-2.5-flash"
    print(f"  [gemini] vision  model={model}  file={vision_file}", file=sys.stderr, flush=True)

    image_bytes = Path(vision_file).read_bytes()
    mime = "image/png" if vision_file.endswith(".png") else "image/jpeg"

    response = client.models.generate_content(
        model=model,
        contents=[
            types.Part.from_bytes(data=image_bytes, mime_type=mime),
            prompt,
        ],
    )
    return response.text


def main():
    parser = argparse.ArgumentParser(description="Gemini image generation / vision analysis")
    parser.add_argument("prompt", help="Image generation prompt or vision analysis question")
    parser.add_argument("output", nargs="?", default=None, help="Output image path (required for generation)")
    parser.add_argument("--vision-file", default=None, help="Input image path for vision analysis")
    parser.add_argument("--model", default=None, help="Force a specific model (skips fallback chain)")
    args = parser.parse_args()

    if not os.environ.get("GEMINI_API_KEY"):
        print("ERROR: GEMINI_API_KEY not set", file=sys.stderr)
        sys.exit(1)

    # Vision analysis path — outputs to stdout
    if args.vision_file:
        result = analyze_image(args.prompt, args.vision_file)
        print(result)
        return

    # Image generation path
    if not args.output:
        print("ERROR: output path required for image generation", file=sys.stderr)
        sys.exit(1)

    models_to_try = [args.model] if args.model else MODELS

    for model in models_to_try:
        for attempt, delay in enumerate(RETRY_DELAYS):
            if delay:
                print(f"  [gemini] waiting {delay}s before retry (attempt {attempt + 1})...", flush=True)
                time.sleep(delay)
            try:
                if generate_image(args.prompt, args.output, model):
                    print(f"  [gemini] ✓ success  model={model}  attempt={attempt + 1}", flush=True)
                    sys.exit(0)
            except Exception as e:
                msg = str(e)
                is_server_error = any(
                    x in msg.lower()
                    for x in ["503", "500", "overloaded", "unavailable", "capacity"]
                )
                print(f"  [gemini] ⚠  {model} attempt {attempt + 1}: {msg[:120]}", flush=True)
                if not is_server_error:
                    break  # Client-side error — skip retries for this model
        print(f"  [gemini] ↩ falling back from {model}", flush=True)

    print("  [gemini] ✗ all models failed", file=sys.stderr, flush=True)
    sys.exit(1)


if __name__ == "__main__":
    main()
