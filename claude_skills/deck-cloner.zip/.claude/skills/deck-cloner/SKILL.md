---
name: deck-cloner
description: "Clone slide deck designs from reference screenshots/images OR from a reference .pptx file, and populate them with content from markdown files, producing editable .pptx files using PptxGenJS. IMPORTANT: This skill OVERRIDES the default pptx editing skill when the user's intent is to REPLICATE or CLONE a design, not just edit content in-place. Use this skill whenever the user wants to: replicate a slide deck's visual design from screenshots or a reference .pptx, clone a presentation's style into a new deck with their own content, create slides that match an existing design system, produce 'pixel-perfect' or 'design-faithful' decks, generate content-aware slides with intelligent visual elements (tables, charts, icons, illustrations). Trigger phrases: 'clone this design', 'match this deck's style', 'replicate these slides', 'make slides from my markdown that look like this', 'use this pptx as a design reference', 'follow this deck's visual DNA'. Also trigger when the user provides BOTH a .pptx file AND separate content (markdown, text, bullet points) — this signals design cloning, not template editing. When a .pptx is provided as a design reference, ALWAYS run the pre-processor first (Phase 0) — never fall through to the generic pptx editing workflow. This skill handles: pptx pre-processing → vision analysis → design token extraction → markdown content analysis → content-aware slide planning → Gemini visual asset generation → PptxGenJS assembly → QA."
---

# Deck Cloner Skill

Clone slide deck designs from reference screenshots OR .pptx files, fill with markdown content, and generate visual assets via Google GenAI Python SDK — all orchestrated by Claude Code.

## ⚠️ CRITICAL: .pptx Reference Routing

When a user provides a `.pptx` file as a **design reference** (not for content editing), you MUST use this skill's pipeline — **do NOT fall through to the generic pptx editing skill**.

**How to tell**: The user provides a .pptx AND separately provides content (markdown, text, outline) to populate into a new deck matching that design. Or they say "clone", "replicate", "match the style of", "use this as a reference/template design".

**What to do**: Run Phase 0 (pre-processor) FIRST. This converts the .pptx to images + extracts XML tokens, which feeds the full creative pipeline. Never directly unpack → edit → repack.

## Architecture

```
      .pptx reference?
            │
            ▼
   ┌──────────────────┐
   │  Phase 0: PPTX   │──→ reference-slides/*.jpg
   │  Pre-processor    │──→ extracted-tokens.json
   │  (MUST run first) │──→ unpacked/ (XML)
   └────────┬─────────┘
            │
            ▼
┌─────────────┐   ┌──────────────┐   ┌────────────────┐
│  Reference   │   │   Markdown   │   │   Gemini CLI   │
│   Images     │   │   Content    │   │  (Imagen/Vision)│
└──────┬───────┘   └──────┬───────┘   └───────┬────────┘
       │                  │                    │
       ▼                  ▼                    │
  ┌──────────┐    ┌──────────────┐             │
  │  Design   │    │   Content    │             │
  │  Tokens   │    │  Classifier  │             │
  └──────┬────┘    └──────┬───────┘             │
         │                │                     │
         ▼                ▼                     │
    ┌──────────────────────────┐                │
    │     Slide Planner        │◄───────────────┘
    │ (layout + visual assets) │────── requests ──►
    └──────────┬───────────────┘
               ▼
    ┌──────────────────────┐
    │  PptxGenJS Generator │
    └──────────┬───────────┘
               ▼
    ┌──────────────────────┐
    │   QA + Iterate       │
    └──────────────────────┘
```

**Claude Code** orchestrates the entire pipeline. **`scripts/gemini-image.py`** (called via `uv run`) handles visual asset generation via the Google GenAI Python SDK.

## Full Workflow

### Phase 0: PPTX Pre-Processing (when reference is a .pptx file)

**This phase is MANDATORY when the input is a .pptx, and must run BEFORE anything else.**

It serves two purposes:
1. **Converts slides to images** → feeds into Phase 1 vision analysis
2. **Extracts design tokens from XML** → fonts, colors, sizes, margins from the actual file

```bash
python scripts/pptx-preprocess.py reference.pptx .
```

This produces:
- `reference-slides/slide-01.jpg`, `slide-02.jpg`, ... (for vision analysis)
- `extracted-tokens.json` (programmatic tokens from XML: theme colors, fonts, sizes, margins)
- `unpacked/` (raw XML for deeper inspection if needed)

The pre-processor extracts **exact values** that vision can't determine precisely:
- Theme color scheme (all accent1-6, dk1, dk2, lt1, lt2 as exact hex)
- Font families from the theme (major/minor fonts)
- Font sizes at every level (from actual `<a:rPr sz="...">` attributes)
- Slide dimensions and layout type
- Margin estimates from element positions

But it **cannot** determine visual style properties that require seeing the rendered output:
- `illustrationStyle` (flat vector? isometric? photographic?)
- `iconStyle` (filled? outline? in circles?)
- Shadow depth and visual weight
- Color *roles* (which accent is used for what purpose)
- Decorative motifs (accent bars, corner marks, patterns)

These come from Phase 1 vision analysis on the generated slide images.

**Merging**: In Phase 1, start with `extracted-tokens.json` as the base, then overlay/refine with vision analysis results. The XML values are ground truth for fonts, colors, and sizes; the vision analysis determines style, motifs, and visual roles.

### Phase 1: Design DNA Extraction

Analyze reference screenshots to extract visual DNA. See `references/vision-analysis-prompt.md` for the detailed prompt template.

Extract into `design-spec.json`. Key fields:

```json
{
  "meta": { "layout": "LAYOUT_16x9", "designStyle": "..." },
  "palette": {
    "primaryBg": "1A1A2E", "secondaryBg": "F5F5F7",
    "headingColor": "FFFFFF", "bodyColor": "333333",
    "mutedColor": "8E8E93", "accent1": "0A84FF", "accent2": "30D158",
    "chartColors": ["0A84FF", "30D158", "FF9F0A", "FF375F"],
    "tableBorder": "E5E5EA", "tableHeaderBg": "1A1A2E",
    "tableStripeBg": "F5F5F7"
  },
  "typography": {
    "headingFont": "Trebuchet MS", "bodyFont": "Calibri",
    "captionFont": "Calibri Light",
    "sizes": { "heroTitle": 44, "slideTitle": 32, "body": 14, "caption": 10 }
  },
  "layout": {
    "margins": { "top": 0.6, "bottom": 0.5, "left": 0.7, "right": 0.7 },
    "contentWidth": 8.6, "columnGap": 0.4, "verticalGap": 0.3
  },
  "motifs": {
    "cornerRadius": 0.1, "iconStyle": "filled-circle", "iconSize": 0.4,
    "accentBarWidth": 0.06, "dividerStyle": "thin-line",
    "shadowStyle": { "type": "outer", "blur": 6, "offset": 2, "color": "000000", "opacity": 0.12 },
    "illustrationStyle": "flat-vector-corporate"
  }
}
```

**Critical**: Extract `illustrationStyle` from reference — this constrains all Gemini prompts later (e.g., "flat vector corporate", "isometric 3D", "hand-drawn sketch", "gradient abstract").

Font matching: see `references/vision-analysis-prompt.md` for the system font mapping table.

### Phase 2: Markdown Content Analysis

Parse the markdown file and classify each section into a **content type**. Read `references/content-classifier.md` for the full classifier logic and all content type definitions.

The classifier produces `slide-plan.json` — an ordered list of slides with:
- Content type (title, stat-callout, data-table, key-points, process-flow, etc.)
- Extracted text, data, bullets
- Visual needs (what Gemini should generate for this slide)
- Layout template to use

### Phase 3: Gemini Visual Asset Generation

For slides needing illustrations, icons, or complex graphics, call `scripts/gemini-image.py` via `uv`. Read `references/gemini-integration.md` for the script, all prompt patterns, and the batch asset pipeline.

**Setup** (once per project — write `scripts/gemini-image.py` from `gemini-integration.md`):
```bash
mkdir -p scripts assets
# Write scripts/gemini-image.py from references/gemini-integration.md
export GEMINI_API_KEY="your-key"
```

Key patterns:
- **Background illustrations**: `uv run --with google-genai scripts/gemini-image.py "PROMPT" ./assets/slide-N-bg.png`
- **Spot illustrations**: Topic-specific icons/graphics constrained to the design palette
- **Chart images**: When PptxGenJS native charts aren't sufficient
- **Vision analysis**: `uv run --with google-genai scripts/gemini-image.py "PROMPT" --vision-file ./ref.png`

Every prompt must include the **style constraint block** derived from `design-spec.json` to keep assets on-brand. The script prints model, file size, and success/failure in real time — no black box.

### Phase 4: PptxGenJS Assembly

Read `/mnt/skills/public/pptx/pptxgenjs.md` for API details and pitfalls.

Build the deck using content-aware slide builders. Read `references/slide-builders.md` for all builder implementations. Each content type maps to a specific layout function that respects the design DNA.

See `scripts/scaffold.js` for the base template with helper factories, icon utilities, and gradient generation.

**Critical PptxGenJS rules** (violations corrupt output):
- NEVER use `#` prefix on hex colors
- NEVER encode opacity in hex strings — use `opacity` property
- NEVER reuse option objects — use factory functions
- Use `breakLine: true` between text array items
- Use `bullet: true` not unicode bullets
- Shadow `offset` must be non-negative

### Phase 5: QA Verification

Mandatory. Your first render is almost never correct.

```bash
node generate-deck.js
python /mnt/skills/public/pptx/scripts/office/soffice.py --headless --convert-to pdf output.pptx
rm -f slide-*.jpg
pdftoppm -jpeg -r 150 output.pdf slide
ls -1 "$PWD"/slide-*.jpg
```

Compare each slide against references. Check design DNA fidelity, content-type treatment, Gemini asset quality, element overlap, and motif consistency. Fix and re-verify at least once.

## Dependencies

```bash
npm install -g pptxgenjs react-icons react react-dom sharp
pip install "markitdown[pptx]" Pillow --break-system-packages

# Image generation — no global install needed; uv handles it inline
export GEMINI_API_KEY="your-key"
# Usage: uv run --with google-genai scripts/gemini-image.py "PROMPT" OUTPUT.png
```

## Output

```
project/
├── design-spec.json          # Reusable design DNA
├── slide-plan.json           # Content-classified slide plan
├── assets/                   # Gemini-generated visual assets
├── generate-deck.js          # Editable PptxGenJS script
└── output.pptx               # Final editable deck
```
