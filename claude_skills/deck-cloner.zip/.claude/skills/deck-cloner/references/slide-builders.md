# Slide Builders Reference

Content-type-aware layout builders for PptxGenJS. Each function takes a slide, presentation, slide plan entry, design spec, and generated assets.

Read `/mnt/skills/public/pptx/pptxgenjs.md` for API details before using these.

## Shared Helpers

Always use factory functions — never share mutable option objects.

```javascript
// Use design spec for all values
function helpers(spec) {
  const M = spec.layout.margins;
  const CW = spec.layout.contentWidth;

  const makeCardShadow = () => ({ ...spec.motifs.shadowStyle });
  const makeAccentBar = (x, y, h) => ({
    x, y, w: spec.motifs.accentBarWidth, h,
    fill: { color: spec.palette.accent1 },
  });

  function addTitle(slide, text, dark = false) {
    slide.addText(text, {
      x: M.left, y: M.top, w: CW, h: 0.6,
      fontSize: spec.typography.sizes.slideTitle,
      fontFace: spec.typography.headingFont,
      color: dark ? spec.palette.headingColor : spec.palette.bodyColor,
      bold: true, margin: 0,
    });
  }

  function addCard(slide, pres, x, y, w, h) {
    slide.addShape(pres.shapes.RECTANGLE, {
      x, y, w, h,
      fill: { color: "FFFFFF" },
      shadow: makeCardShadow(),
    });
  }

  function addFooter(slide, num, total) {
    slide.addText(`${num} / ${total}`, {
      x: M.left + CW - 1.5, y: 5.1, w: 1.5, h: 0.3,
      fontSize: spec.typography.sizes.caption,
      fontFace: spec.typography.captionFont,
      color: spec.palette.mutedColor, align: "right", margin: 0,
    });
  }

  return { M, CW, makeCardShadow, makeAccentBar, addTitle, addCard, addFooter };
}
```

## Builder: title-slide

```javascript
function buildTitleSlide(slide, pres, plan, spec, assets) {
  const { M, CW } = helpers(spec);

  // Background: Gemini illustration or solid dark
  const bgAsset = assets[`slide-${plan.index}-bg`];
  if (bgAsset) {
    slide.background = { path: bgAsset };
  } else {
    slide.background = { color: spec.palette.primaryBg };
  }

  // Title
  slide.addText(plan.heading, {
    x: M.left, y: 1.5, w: CW, h: 1.5,
    fontSize: spec.typography.sizes.heroTitle,
    fontFace: spec.typography.headingFont,
    color: spec.palette.headingColor, bold: true, margin: 0,
  });

  // Subtitle (first line of content)
  const subtitle = plan.content.split("\n")[0] || "";
  if (subtitle) {
    slide.addText(subtitle, {
      x: M.left, y: 3.2, w: CW, h: 0.6,
      fontSize: 18, fontFace: spec.typography.bodyFont,
      color: spec.palette.mutedColor, margin: 0,
    });
  }
}
```

## Builder: section-divider

```javascript
function buildSectionDivider(slide, pres, plan, spec, assets) {
  const { M, CW } = helpers(spec);
  const bgAsset = assets[`slide-${plan.index}-bg`];

  slide.background = bgAsset
    ? { path: bgAsset }
    : { color: spec.palette.primaryBg };

  slide.addText(plan.heading, {
    x: M.left, y: 2.0, w: CW, h: 1.2,
    fontSize: 40, fontFace: spec.typography.headingFont,
    color: spec.palette.headingColor, bold: true,
    margin: 0, valign: "middle",
  });

  if (plan.content && plan.content.trim().length > 0) {
    slide.addText(plan.content.trim(), {
      x: M.left, y: 3.4, w: CW * 0.6, h: 0.5,
      fontSize: 16, fontFace: spec.typography.bodyFont,
      color: spec.palette.mutedColor, margin: 0,
    });
  }
}
```

## Builder: narrative

Text on left, illustration on right.

```javascript
function buildNarrativeSlide(slide, pres, plan, spec, assets, total) {
  const { M, CW, addTitle, addFooter } = helpers(spec);
  slide.background = { color: spec.palette.secondaryBg };
  addTitle(slide, plan.heading);

  const spotAsset = assets[`slide-${plan.index}-spot`];
  const textW = spotAsset ? CW * 0.55 : CW;
  const imgW = CW * 0.4;

  // Text block
  slide.addText(plan.content, {
    x: M.left, y: 1.4, w: textW, h: 3.5,
    fontSize: spec.typography.sizes.body,
    fontFace: spec.typography.bodyFont,
    color: spec.palette.bodyColor, valign: "top", margin: 0,
    lineSpacingMultiple: 1.4,
  });

  // Spot illustration
  if (spotAsset) {
    slide.addImage({
      path: spotAsset,
      x: M.left + textW + spec.layout.columnGap,
      y: 1.4, w: imgW, h: imgW,
      sizing: { type: "contain", w: imgW, h: 3.0 },
    });
  }

  addFooter(slide, plan.index, total);
}
```

## Builder: key-points

Card grid with icons.

```javascript
function buildKeyPointsSlide(slide, pres, plan, spec, assets, total) {
  const { M, CW, addTitle, addCard, addFooter } = helpers(spec);
  slide.background = { color: spec.palette.secondaryBg };
  addTitle(slide, plan.heading);

  const items = plan.bullets;
  const cols = items.length <= 3 ? items.length : Math.min(3, Math.ceil(items.length / 2));
  const rows = Math.ceil(items.length / cols);
  const colW = (CW - spec.layout.columnGap * (cols - 1)) / cols;
  const rowH = rows === 1 ? 3.2 : 1.6;

  items.forEach((item, i) => {
    const col = i % cols;
    const row = Math.floor(i / cols);
    const x = M.left + col * (colW + spec.layout.columnGap);
    const y = 1.4 + row * (rowH + spec.layout.verticalGap);

    addCard(slide, pres, x, y, colW, rowH);

    // Icon (Gemini asset or react-icon placeholder)
    const iconAsset = assets[`slide-${plan.index}-icon-${i}`];
    if (iconAsset) {
      slide.addImage({
        path: iconAsset, x: x + 0.2, y: y + 0.2,
        w: spec.motifs.iconSize, h: spec.motifs.iconSize,
      });
    } else {
      // Colored circle placeholder for icon
      slide.addShape(pres.shapes.OVAL, {
        x: x + 0.2, y: y + 0.2,
        w: spec.motifs.iconSize, h: spec.motifs.iconSize,
        fill: { color: spec.palette.accent1, transparency: 85 },
      });
    }

    // Heading
    const textX = x + 0.2 + spec.motifs.iconSize + 0.15;
    const textW = colW - (spec.motifs.iconSize + 0.55);
    slide.addText(item.heading, {
      x: textX, y: y + 0.2, w: textW, h: 0.35,
      fontSize: 13, fontFace: spec.typography.headingFont,
      color: spec.palette.bodyColor, bold: true, margin: 0,
    });

    if (item.body) {
      slide.addText(item.body, {
        x: textX, y: y + 0.55, w: textW, h: rowH - 0.75,
        fontSize: 11, fontFace: spec.typography.bodyFont,
        color: spec.palette.mutedColor, margin: 0, valign: "top",
      });
    }
  });

  addFooter(slide, plan.index, total);
}
```

## Builder: stat-callout

Big numbers with trend indicators.

```javascript
function buildStatSlide(slide, pres, plan, spec, assets, total) {
  const { M, CW, addTitle, addCard, addFooter } = helpers(spec);
  slide.background = { color: spec.palette.secondaryBg };
  addTitle(slide, plan.heading);

  const stats = plan.stats || [];
  const count = Math.min(stats.length, 4);
  const colW = (CW - spec.layout.columnGap * (count - 1)) / count;

  stats.slice(0, 4).forEach((stat, i) => {
    const x = M.left + i * (colW + spec.layout.columnGap);
    const y = 1.6;
    const h = 2.8;

    addCard(slide, pres, x, y, colW, h);

    // Accent bar
    slide.addShape(pres.shapes.RECTANGLE, {
      x, y, w: spec.motifs.accentBarWidth, h,
      fill: { color: spec.palette.accent1 },
    });

    // Value (big number)
    slide.addText(stat.value, {
      x: x + 0.3, y: y + 0.4, w: colW - 0.5, h: 1.0,
      fontSize: 48, fontFace: spec.typography.headingFont,
      color: spec.palette.accent1, bold: true, margin: 0,
    });

    // Label
    slide.addText(stat.label, {
      x: x + 0.3, y: y + 1.5, w: colW - 0.5, h: 0.5,
      fontSize: 12, fontFace: spec.typography.captionFont,
      color: spec.palette.mutedColor, margin: 0,
    });

    // Trend indicator (text-based fallback if no icon)
    const trendSymbol = stat.trend === "up" ? "↑" : stat.trend === "down" ? "↓" : "—";
    const trendColor = stat.trend === "up" ? spec.palette.accent2
                     : stat.trend === "down" ? "FF375F"
                     : spec.palette.mutedColor;
    slide.addText(trendSymbol, {
      x: x + colW - 0.6, y: y + 0.4, w: 0.4, h: 0.4,
      fontSize: 20, color: trendColor, align: "center", margin: 0,
    });
  });

  addFooter(slide, plan.index, total);
}
```

## Builder: data-table

Styled table matching the design DNA.

```javascript
function buildTableSlide(slide, pres, plan, spec, assets, total) {
  const { M, CW, addTitle, addFooter } = helpers(spec);
  slide.background = { color: spec.palette.secondaryBg };
  addTitle(slide, plan.heading);

  const { headers, rows } = plan.tableData;
  if (!headers || !rows) return;

  const tableRows = [
    // Header row
    headers.map(h => ({
      text: h, options: {
        bold: true, color: "FFFFFF",
        fill: { color: spec.palette.tableHeaderBg || spec.palette.primaryBg },
        fontSize: 12, fontFace: spec.typography.bodyFont,
        align: "center", valign: "middle",
      }
    })),
    // Data rows with alternating stripes
    ...rows.map((row, i) => row.map(cell => ({
      text: String(cell), options: {
        fontSize: 11, fontFace: spec.typography.bodyFont,
        color: spec.palette.bodyColor,
        fill: { color: i % 2 === 0 ? "FFFFFF" : (spec.palette.tableStripeBg || spec.palette.secondaryBg) },
        valign: "middle",
      }
    })))
  ];

  const colW = headers.map(() => CW / headers.length);

  slide.addTable(tableRows, {
    x: M.left, y: 1.4, w: CW,
    border: { pt: 0.5, color: spec.palette.tableBorder || "E5E5EA" },
    colW,
    rowH: [0.45, ...rows.map(() => 0.4)],
  });

  addFooter(slide, plan.index, total);
}
```

## Builder: process-flow

Numbered timeline steps.

```javascript
function buildProcessSlide(slide, pres, plan, spec, assets, total) {
  const { M, CW, addTitle, addFooter } = helpers(spec);
  slide.background = { color: spec.palette.secondaryBg };
  addTitle(slide, plan.heading);

  const steps = plan.steps || [];
  const count = Math.min(steps.length, 5);
  const stepW = CW / count;
  const circleSize = 0.5;
  const y = 2.2;

  steps.slice(0, 5).forEach((step, i) => {
    const cx = M.left + i * stepW + stepW / 2;

    // Connector line (skip last)
    if (i < count - 1) {
      slide.addShape(pres.shapes.LINE, {
        x: cx + circleSize / 2 + 0.05, y: y + circleSize / 2,
        w: stepW - circleSize - 0.1, h: 0,
        line: { color: spec.palette.mutedColor, width: 1.5, dashType: "dash" },
      });
    }

    // Number circle
    slide.addShape(pres.shapes.OVAL, {
      x: cx - circleSize / 2, y,
      w: circleSize, h: circleSize,
      fill: { color: spec.palette.accent1 },
    });
    slide.addText(String(i + 1), {
      x: cx - circleSize / 2, y,
      w: circleSize, h: circleSize,
      fontSize: 16, fontFace: spec.typography.headingFont,
      color: "FFFFFF", bold: true,
      align: "center", valign: "middle", margin: 0,
    });

    // Step text
    slide.addText(step, {
      x: cx - stepW * 0.4, y: y + circleSize + 0.3,
      w: stepW * 0.8, h: 1.5,
      fontSize: 11, fontFace: spec.typography.bodyFont,
      color: spec.palette.bodyColor, align: "center",
      valign: "top", margin: 0,
    });
  });

  addFooter(slide, plan.index, total);
}
```

## Builder: quote

```javascript
function buildQuoteSlide(slide, pres, plan, spec, assets, total) {
  const { M, CW } = helpers(spec);
  slide.background = { color: spec.palette.secondaryBg };

  // Extract quote text and attribution
  const quoteLines = plan.content.split("\n").filter(l => l.startsWith(">"));
  const quoteText = quoteLines.map(l => l.replace(/^>\s*/, "")).join(" ");
  const attribution = plan.content.split("\n").find(l => !l.startsWith(">") && l.trim()) || "";

  // Accent bar
  slide.addShape(pres.shapes.RECTANGLE, {
    x: M.left, y: 1.5, w: 0.08, h: 2.5,
    fill: { color: spec.palette.accent1 },
  });

  // Quote text
  slide.addText(`"${quoteText}"`, {
    x: M.left + 0.4, y: 1.5, w: CW - 0.4, h: 2.0,
    fontSize: 22, fontFace: spec.typography.headingFont,
    color: spec.palette.bodyColor, italic: true,
    valign: "middle", margin: 0, lineSpacingMultiple: 1.4,
  });

  // Attribution
  if (attribution) {
    slide.addText(attribution.replace(/^[-—–]\s*/, "— "), {
      x: M.left + 0.4, y: 3.6, w: CW - 0.4, h: 0.4,
      fontSize: 14, fontFace: spec.typography.captionFont,
      color: spec.palette.mutedColor, margin: 0,
    });
  }
}
```

## Builder: technical (code block)

```javascript
function buildTechnicalSlide(slide, pres, plan, spec, assets, total) {
  const { M, CW, addTitle, addFooter } = helpers(spec);
  slide.background = { color: spec.palette.secondaryBg };
  addTitle(slide, plan.heading);

  // Extract code from markdown code block
  const codeMatch = plan.content.match(/```(?:\w+)?\n([\s\S]*?)```/);
  const code = codeMatch ? codeMatch[1].trim() : plan.content;

  // Dark code card
  slide.addShape(pres.shapes.RECTANGLE, {
    x: M.left, y: 1.4, w: CW, h: 3.5,
    fill: { color: "1E1E1E" },
    shadow: { type: "outer", blur: 8, offset: 3, color: "000000", opacity: 0.2, angle: 135 },
  });

  slide.addText(code, {
    x: M.left + 0.3, y: 1.6, w: CW - 0.6, h: 3.1,
    fontSize: 11, fontFace: "Consolas",
    color: "D4D4D4", valign: "top", margin: 0,
    lineSpacingMultiple: 1.3,
  });

  addFooter(slide, plan.index, total);
}
```

## Builder: closing

```javascript
function buildClosingSlide(slide, pres, plan, spec, assets) {
  const { M, CW } = helpers(spec);
  const bgAsset = assets[`slide-${plan.index}-bg`];

  slide.background = bgAsset
    ? { path: bgAsset }
    : { color: spec.palette.primaryBg };

  slide.addText(plan.heading || "Thank You", {
    x: M.left, y: 1.8, w: CW, h: 1.2,
    fontSize: 40, fontFace: spec.typography.headingFont,
    color: spec.palette.headingColor, bold: true,
    align: "center", margin: 0,
  });

  // Contact info from content
  const contactText = plan.content.replace(/^[\s>*-]+/gm, "").trim();
  if (contactText) {
    slide.addText(contactText, {
      x: M.left + CW * 0.2, y: 3.3, w: CW * 0.6, h: 1.0,
      fontSize: 14, fontFace: spec.typography.bodyFont,
      color: spec.palette.mutedColor, align: "center", margin: 0,
    });
  }
}
```

## Master Router

Route each slide plan entry to the correct builder:

```javascript
const BUILDERS = {
  "title-slide": buildTitleSlide,
  "section-divider": buildSectionDivider,
  "narrative": buildNarrativeSlide,
  "key-points": buildKeyPointsSlide,
  "detailed-list": buildKeyPointsSlide, // reuse with different column count
  "stat-callout": buildStatSlide,
  "data-table": buildTableSlide,
  "process-flow": buildProcessSlide,
  "comparison": buildComparisonSlide,   // implement similar to key-points
  "technical": buildTechnicalSlide,
  "quote": buildQuoteSlide,
  "chart-data": buildChartSlide,        // use PptxGenJS native charts
  "closing": buildClosingSlide,
};

async function buildAllSlides(pres, slidePlan, designSpec, assets) {
  const total = slidePlan.totalSlides;
  for (const plan of slidePlan.slides) {
    const slide = pres.addSlide();
    const builder = BUILDERS[plan.type] || buildNarrativeSlide;
    await builder(slide, pres, plan, designSpec, assets, total);
  }
}
```
