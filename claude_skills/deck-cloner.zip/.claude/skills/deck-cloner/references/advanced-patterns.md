# Advanced Design Replication Patterns

## Multi-Screenshot Workflow

When processing multiple screenshots into a full deck:

### 1. Global Pass First
Scan ALL screenshots before coding any slides. Identify:
- Recurring elements (headers, footers, page numbers, logos)
- Color system (which colors appear on which slide types)
- Layout categories (group slides by type: title, content, data, transition)
- Typography hierarchy across the full deck

### 2. Build Shared Infrastructure
Create reusable components before individual slides:

```javascript
// Design tokens from spec
const COLORS = {
  darkBg: "1A1A2E",
  lightBg: "F5F5F7",
  heading: "FFFFFF",
  body: "333333",
  muted: "8E8E93",
  accent: "0A84FF",
};

const FONTS = {
  heading: "Trebuchet MS",
  body: "Calibri",
  caption: "Calibri Light",
};

const LAYOUT = {
  margin: { t: 0.6, b: 0.5, l: 0.7, r: 0.7 },
  contentW: 8.6,
  gap: 0.3,
};

// Factory functions for repeated elements
const makeFooter = (slide, pres, text) => {
  slide.addText(text, {
    x: LAYOUT.margin.l,
    y: 5.1,
    w: LAYOUT.contentW,
    h: 0.3,
    fontSize: 9,
    color: COLORS.muted,
    fontFace: FONTS.caption,
  });
};

const makePageNumber = (slide, num, total) => {
  slide.addText(`${num} / ${total}`, {
    x: 8.5,
    y: 5.1,
    w: 1,
    h: 0.3,
    fontSize: 9,
    color: COLORS.muted,
    fontFace: FONTS.caption,
    align: "right",
  });
};

const makeCard = (slide, pres, x, y, w, h, content) => {
  // Fresh shadow object each time
  slide.addShape(pres.shapes.RECTANGLE, {
    x, y, w, h,
    fill: { color: "FFFFFF" },
    shadow: { type: "outer", blur: 6, offset: 2, color: "000000", opacity: 0.12, angle: 135 },
  });
  // Accent bar
  slide.addShape(pres.shapes.RECTANGLE, {
    x, y, w: 0.06, h,
    fill: { color: COLORS.accent },
  });
  // Content text
  slide.addText(content, {
    x: x + 0.2, y: y + 0.15, w: w - 0.35, h: h - 0.3,
    fontSize: 14, fontFace: FONTS.body, color: COLORS.body,
    valign: "top", margin: 0,
  });
};
```

### 3. Slide Type Templates

#### Title Slide (Dark)
```javascript
function buildTitleSlide(pres, title, subtitle) {
  const slide = pres.addSlide();
  slide.background = { color: COLORS.darkBg };
  
  slide.addText(title, {
    x: LAYOUT.margin.l, y: 1.5,
    w: LAYOUT.contentW, h: 1.5,
    fontSize: 44, fontFace: FONTS.heading,
    color: COLORS.heading, bold: true,
    margin: 0,
  });
  
  slide.addText(subtitle, {
    x: LAYOUT.margin.l, y: 3.2,
    w: LAYOUT.contentW, h: 0.6,
    fontSize: 18, fontFace: FONTS.body,
    color: COLORS.muted,
    margin: 0,
  });
  
  return slide;
}
```

#### Content Slide (Light, 2-Column)
```javascript
function buildTwoColSlide(pres, title, leftContent, rightContent, slideNum, totalSlides) {
  const slide = pres.addSlide();
  slide.background = { color: COLORS.lightBg };
  
  // Title
  slide.addText(title, {
    x: LAYOUT.margin.l, y: LAYOUT.margin.t,
    w: LAYOUT.contentW, h: 0.6,
    fontSize: 28, fontFace: FONTS.heading,
    color: COLORS.darkBg, bold: true,
    margin: 0,
  });
  
  const colW = (LAYOUT.contentW - LAYOUT.gap) / 2;
  const contentY = LAYOUT.margin.t + 0.9;
  const contentH = 3.5;
  
  // Left column card
  makeCard(slide, pres, LAYOUT.margin.l, contentY, colW, contentH, leftContent);
  
  // Right column card
  makeCard(slide, pres, LAYOUT.margin.l + colW + LAYOUT.gap, contentY, colW, contentH, rightContent);
  
  makePageNumber(slide, slideNum, totalSlides);
  return slide;
}
```

## Icon Style Matching

### Detection Guide
| Visual Cue | Icon Set | Import From |
|-----------|----------|-------------|
| Filled solid shapes | Font Awesome | `react-icons/fa` |
| Outlined/stroke only | Heroicons | `react-icons/hi` |
| Rounded, Google-style | Material Design | `react-icons/md` |
| Clean, minimal | Feather Icons | `react-icons/fi` |
| Bootstrap-style | Bootstrap Icons | `react-icons/bi` |

### Icon-in-Circle Pattern
Many professional decks place icons inside colored circles:

```javascript
async function addIconInCircle(slide, pres, IconComponent, x, y, circleSize, iconColor, circleFill) {
  // Circle background
  slide.addShape(pres.shapes.OVAL, {
    x, y, w: circleSize, h: circleSize,
    fill: { color: circleFill },
  });
  
  // Render icon
  const iconData = await iconToBase64Png(IconComponent, iconColor, 256);
  const iconPadding = circleSize * 0.25;
  slide.addImage({
    data: iconData,
    x: x + iconPadding, y: y + iconPadding,
    w: circleSize - iconPadding * 2,
    h: circleSize - iconPadding * 2,
  });
}
```

## Gradient Backgrounds

PptxGenJS doesn't support native gradients. Use generated gradient images:

```javascript
const sharp = require("sharp");

async function createGradientBg(width, height, color1, color2, direction = "horizontal") {
  // Create SVG gradient
  const svg = `<svg width="${width}" height="${height}" xmlns="http://www.w3.org/2000/svg">
    <defs>
      <linearGradient id="g" ${direction === "vertical" ? 'x1="0" y1="0" x2="0" y2="1"' : 'x1="0" y1="0" x2="1" y2="0"'}>
        <stop offset="0%" stop-color="#${color1}"/>
        <stop offset="100%" stop-color="#${color2}"/>
      </linearGradient>
    </defs>
    <rect width="${width}" height="${height}" fill="url(#g)"/>
  </svg>`;
  
  const pngBuffer = await sharp(Buffer.from(svg)).png().toBuffer();
  return "image/png;base64," + pngBuffer.toString("base64");
}

// Usage
const bgData = await createGradientBg(1920, 1080, "1A1A2E", "16213E", "vertical");
slide.background = { data: bgData };
```

## Data Visualization Matching

When reference slides contain charts or data displays:

### Large Stat Callouts
```javascript
function addStatCallout(slide, x, y, value, label, accentColor) {
  slide.addText(value, {
    x, y, w: 2.5, h: 1,
    fontSize: 48, fontFace: FONTS.heading,
    color: accentColor, bold: true,
    margin: 0,
  });
  slide.addText(label, {
    x, y: y + 0.9, w: 2.5, h: 0.4,
    fontSize: 12, fontFace: FONTS.caption,
    color: COLORS.muted,
    margin: 0,
  });
}
```

### Timeline/Process Flow
```javascript
function addProcessStep(slide, pres, x, y, stepNum, title, desc, isLast) {
  // Step circle
  slide.addShape(pres.shapes.OVAL, {
    x, y, w: 0.5, h: 0.5,
    fill: { color: COLORS.accent },
  });
  slide.addText(String(stepNum), {
    x, y, w: 0.5, h: 0.5,
    fontSize: 16, fontFace: FONTS.heading,
    color: "FFFFFF", bold: true,
    align: "center", valign: "middle",
  });
  
  // Connector line (skip for last step)
  if (!isLast) {
    slide.addShape(pres.shapes.LINE, {
      x: x + 0.55, y: y + 0.25,
      w: 1.2, h: 0,
      line: { color: COLORS.muted, width: 1.5, dashType: "dash" },
    });
  }
  
  // Text
  slide.addText(title, {
    x: x - 0.3, y: y + 0.6, w: 1.1, h: 0.4,
    fontSize: 12, fontFace: FONTS.heading,
    color: COLORS.darkBg, bold: true,
    align: "center", margin: 0,
  });
}
```

## QA Checklist

After generating, compare each slide against its reference for:

- [ ] Background color/gradient matches
- [ ] Title font, size, weight, color, position
- [ ] Body text font, size, color, alignment
- [ ] Element positions (within ~0.2" tolerance)
- [ ] Card/box shadows and corner radius
- [ ] Accent elements (bars, lines, circles) present
- [ ] Icon style matches (filled vs outline)
- [ ] Spacing between elements is proportional
- [ ] Footer/page number placement
- [ ] Overall "silhouette" matches when squinting
