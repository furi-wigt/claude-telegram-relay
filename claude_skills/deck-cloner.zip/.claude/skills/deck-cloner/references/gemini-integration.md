# Gemini Image Generation via Python SDK

How Claude Code calls the Google GenAI Python SDK (via `uv`) to generate design-matched visual assets for slides. No Gemini CLI required.

## Why Python SDK instead of Gemini CLI

`gemini -p "..." --yolo` does NOT call the image model directly — it routes through the CLI's reasoning loop, which writes and executes PIL/Pillow drawing code as a fallback. The Python SDK calls the image generation endpoint directly and transparently.

## Prerequisites

```bash
# Ensure GEMINI_API_KEY is set
export GEMINI_API_KEY="your-key"

# uv must be installed (usually already present)
which uv || curl -LsSf https://astral.sh/uv/install.sh | sh
```

No global package installs needed — `uv run --with google-genai` handles the dependency inline.

## The Image Generation Script

The canonical script lives at `skills/deck-cloner/scripts/gemini-image.py`.

At project setup, copy it into the project:

```bash
cp "$(dirname $(claude --print-skill-path deck-cloner 2>/dev/null || echo ~/.claude/skills/deck-cloner))/scripts/gemini-image.py" ./scripts/gemini-image.py
# or simply copy it manually from ~/.claude/skills/deck-cloner/scripts/gemini-image.py
```

The script handles image generation with model fallback and vision analysis in ~80 lines. See the source for details.

## Invocation Syntax

Replace every former `gemini -p "..." --yolo` call with:

```bash
# Image generation
uv run --with google-genai scripts/gemini-image.py "PROMPT_TEXT" ./assets/slide-N-TYPE.png

# Vision analysis (outputs text/JSON to stdout)
uv run --with google-genai scripts/gemini-image.py "PROMPT_TEXT" --vision-file ./reference-slides/slide-N.png
```

Output is transparent — the script prints exactly which model is used, file size, and success/failure to stdout in real time.

## Model Configuration

| Model ID | Name | Notes |
|---|---|---|
| `gemini-3.1-flash-image-preview` | Nano Banana 2 | Default. Fast, 4K capable. Preview = limited GPU. |
| `gemini-3-pro-image-preview` | Nano Banana Pro | Higher quality, 3-4x more reliable. |
| `gemini-2.5-flash-image` | Nano Banana original | Stable last-resort fallback. |

The script tries all three automatically with exponential backoff on 500/503 errors.

## Core Principle: Style-Constrained Prompts

Every image prompt MUST include a **style constraint block** derived from `design-spec.json`. Build this in your batch pipeline script:

```python
def build_style_constraint(spec):
    return (
        f"STYLE RULES (mandatory): "
        f"Use ONLY #{spec['palette']['accent1']} (primary), "
        f"#{spec['palette']['accent2']} (secondary), "
        f"#{spec['palette']['primaryBg']} (dark), "
        f"#{spec['palette']['secondaryBg']} (light). "
        f"Illustration style: {spec['motifs']['illustrationStyle']}. "
        f"No text, no labels, no watermarks. Clean, professional, presentation-ready."
    )
```

## Prompt Patterns

### Pattern A: Background Illustrations (16:9)

```bash
uv run --with google-genai scripts/gemini-image.py \
  "Generate an image. STYLE RULES: Use ONLY #${ACCENT1} (primary), #${PRIMARY_BG} (dark). Style: ${ILLUST_STYLE}. No text, no labels. Background: solid #${PRIMARY_BG}. Aspect ratio 16:9, 1920x1080. SUBJECT: Subtle ${ILLUST_STYLE} illustration representing '${HEADING}'. Keep center area clear for text overlay. Heavier detail on edges and corners." \
  ./assets/slide-${N}-bg.png
```

**Example (flat vector corporate):**
```bash
uv run --with google-genai scripts/gemini-image.py \
  "Generate an image. STYLE RULES: Use ONLY #0A84FF (blue), #30D158 (green), #1A1A2E (navy). Style: flat vector corporate, minimal geometric shapes. No text, no labels. Background: solid #1A1A2E. Aspect ratio 16:9, 1920x1080. SUBJECT: Abstract cloud infrastructure network with floating server nodes, connection lines, and shield icons. Subtle and atmospheric — designed as a slide background with text overlay space in center." \
  ./assets/slide-1-bg.png
```

### Pattern B: Spot Illustrations (Square)

```bash
uv run --with google-genai scripts/gemini-image.py \
  "Generate an image. STYLE RULES: Use ONLY #${ACCENT1}, #${ACCENT2}, #${PRIMARY_BG}. Style: ${ILLUST_STYLE}. No text. Background: white (#FFFFFF). Aspect ratio 1:1, 512x512. SUBJECT: ${ILLUST_STYLE} illustration of '${TOPIC}'. Single focused subject, centered composition." \
  ./assets/slide-${N}-spot.png
```

### Pattern C: Icon Sets

```bash
uv run --with google-genai scripts/gemini-image.py \
  "Generate an image. STYLE RULES: Use ONLY #${ACCENT1}, #${ACCENT2}. Style: ${ILLUST_STYLE}. Background: white. 256x256 square. SUBJECT: Single icon representing '${CONCEPT}' in ${ILLUST_STYLE} style. Simple, bold, recognizable at small sizes." \
  ./assets/slide-${N}-icon-${I}.png
```

### Pattern D: Chart/Data Visualization Images

```bash
uv run --with google-genai scripts/gemini-image.py \
  "Generate an image. STYLE RULES: Use ONLY #${ACCENT1}, #${ACCENT2}, #${SECONDARY_BG}. Style: ${ILLUST_STYLE}. Background: #${SECONDARY_BG}. Aspect ratio 16:9, 1920x1080. SUBJECT: Clean modern ${CHART_TYPE} chart showing: ${DATA_DESCRIPTION}. Bar/line colors: #${ACCENT1}, #${ACCENT2}. Axis labels in #${BODY_COLOR}. Style: minimal, premium, corporate slide deck." \
  ./assets/slide-${N}-chart.png
```

### Pattern E: Vision Analysis (Reference Screenshot)

```bash
uv run --with google-genai scripts/gemini-image.py \
  "Analyze this image. Extract as JSON: {\"colors\": {\"background\": \"hex\", \"heading\": \"hex\", \"body\": \"hex\", \"accent\": \"hex\"}, \"fonts\": {\"heading\": \"classification\", \"body\": \"classification\"}, \"layout\": {\"columns\": N, \"margins\": \"description\"}, \"elements\": [{\"type\": \"...\", \"position\": \"...\", \"style\": \"...\"}], \"motifs\": [\"description\"]}. Be precise with hex colors — sample from flat areas, not gradients." \
  --vision-file ./reference-slides/slide-${N}.png
```

Capture the JSON output:
```bash
DESIGN_JSON=$(uv run --with google-genai scripts/gemini-image.py "..." --vision-file ./ref.png)
echo "$DESIGN_JSON" > design-spec.json
```

## Batch Asset Pipeline

Process all visual needs from `slide-plan.json`:

```bash
#!/bin/bash
# scripts/gemini-asset-pipeline.sh
# Run: bash scripts/gemini-asset-pipeline.sh

set -e
ASSETS_DIR="./assets"
mkdir -p "$ASSETS_DIR"

PLAN="slide-plan.json"
SPEC="design-spec.json"

ACCENT1=$(jq -r '.palette.accent1' "$SPEC")
ACCENT2=$(jq -r '.palette.accent2' "$SPEC")
PRIMARY_BG=$(jq -r '.palette.primaryBg' "$SPEC")
SECONDARY_BG=$(jq -r '.palette.secondaryBg' "$SPEC")
ILLUST_STYLE=$(jq -r '.motifs.illustrationStyle' "$SPEC")

STYLE_RULES="STYLE RULES: Use ONLY #${ACCENT1} (primary), #${ACCENT2} (secondary), #${PRIMARY_BG} (dark), #${SECONDARY_BG} (light). Style: ${ILLUST_STYLE}. No text, no labels, clean professional quality."

SLIDE_COUNT=$(jq '.slides | length' "$PLAN")

run_gemini() {
  local PROMPT="$1"
  local OUTPUT="$2"
  uv run --with google-genai scripts/gemini-image.py "$PROMPT" "$OUTPUT"
}

for ((i=0; i<SLIDE_COUNT; i++)); do
  SLIDE_TYPE=$(jq -r ".slides[$i].type" "$PLAN")
  SLIDE_IDX=$(jq -r ".slides[$i].index" "$PLAN")
  VISUAL_TYPE=$(jq -r ".slides[$i].visualNeeds.type" "$PLAN")
  HEADING=$(jq -r ".slides[$i].heading" "$PLAN")

  if [ "$VISUAL_TYPE" = "none" ]; then
    echo "⏭️  Slide $SLIDE_IDX ($SLIDE_TYPE): No visual assets needed"
    continue
  fi

  echo "🎨 Slide $SLIDE_IDX ($SLIDE_TYPE): Generating $VISUAL_TYPE..."

  case "$VISUAL_TYPE" in
    "background-illustration"|"abstract-background")
      OUTPUT="$ASSETS_DIR/slide-${SLIDE_IDX}-bg.png"
      [ -f "$OUTPUT" ] && echo "   ↩️  Already exists, skipping" && continue
      run_gemini "${STYLE_RULES} Background: solid #${PRIMARY_BG}. Aspect ratio 16:9, 1920x1080. SUBJECT: Subtle ${ILLUST_STYLE} illustration representing '${HEADING}'. Keep center clear for text overlay." "$OUTPUT" \
        || echo "⚠️  Failed for slide $SLIDE_IDX bg — will use solid color fallback"
      ;;

    "spot-illustration")
      OUTPUT="$ASSETS_DIR/slide-${SLIDE_IDX}-spot.png"
      [ -f "$OUTPUT" ] && echo "   ↩️  Already exists, skipping" && continue
      run_gemini "${STYLE_RULES} Background: white. 1:1 aspect, 512x512. SUBJECT: ${ILLUST_STYLE} illustration of '${HEADING}'. Single focused subject." "$OUTPUT" \
        || echo "⚠️  Failed for slide $SLIDE_IDX spot"
      ;;

    "per-item-icons")
      if [ "$ILLUST_STYLE" != "flat-vector-corporate" ]; then
        BULLET_COUNT=$(jq ".slides[$i].bullets | length" "$PLAN")
        for ((j=0; j<BULLET_COUNT; j++)); do
          BULLET_HEADING=$(jq -r ".slides[$i].bullets[$j].heading" "$PLAN")
          OUTPUT="$ASSETS_DIR/slide-${SLIDE_IDX}-icon-${j}.png"
          [ -f "$OUTPUT" ] && continue
          run_gemini "${STYLE_RULES} Background: white. 256x256 square. SUBJECT: Single icon for '${BULLET_HEADING}'. ${ILLUST_STYLE} style." "$OUTPUT" || true
        done
      fi
      ;;
  esac
done

echo ""
echo "✅ Asset generation complete. Generated assets:"
ls -la "$ASSETS_DIR/"
```

## SVG Fallbacks (when all models fail)

When the script exits with code 1, generate a programmatic placeholder via Node.js + sharp:

```javascript
const sharp = require("sharp");
const fs = require("fs");

async function generateFallback(need, slideIndex, spec) {
  const fallbackPath = `./assets/slide-${slideIndex}-${need.type}.png`;

  if (need.type.includes("background")) {
    const svg = `<svg width="1920" height="1080" xmlns="http://www.w3.org/2000/svg">
      <defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">
        <stop offset="0%" stop-color="#${spec.palette.primaryBg}"/>
        <stop offset="100%" stop-color="#${spec.palette.accent1}" stop-opacity="0.15"/>
      </linearGradient></defs>
      <rect width="1920" height="1080" fill="url(#g)"/>
    </svg>`;
    await sharp(Buffer.from(svg)).png().toFile(fallbackPath);
    return fallbackPath;
  }

  if (need.type.includes("icon") || need.type.includes("spot")) {
    const svg = `<svg width="512" height="512" xmlns="http://www.w3.org/2000/svg">
      <circle cx="256" cy="256" r="200" fill="#${spec.palette.accent1}" opacity="0.15"/>
      <circle cx="256" cy="256" r="120" fill="#${spec.palette.accent1}" opacity="0.3"/>
    </svg>`;
    await sharp(Buffer.from(svg)).png().toFile(fallbackPath);
    return fallbackPath;
  }

  return null;
}
```
