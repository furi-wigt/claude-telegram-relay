# Vision Analysis Prompt Template

Use this prompt when analyzing reference slide screenshots. Copy and adapt as needed.

## Analysis Prompt

```
Analyze this slide screenshot as a professional graphic designer reverse-engineering the design system. Extract every visual detail needed to recreate it programmatically.

## Color Palette
- Background: exact hex color (sample from the dominant area)
- Heading text color
- Body text color  
- Muted/caption text color
- Accent color(s) — used for highlights, icons, buttons, bars
- Any gradients (direction + color stops)
- Overlay/transparency patterns

## Typography
For each text level (heading, subheading, body, caption):
- Font family classification (geometric sans, humanist sans, serif, slab, mono, display)
- Weight (light, regular, medium, bold, black)
- Approximate size in points (use slide proportions — heading ~36-44pt, body ~14-16pt)
- Case treatment (uppercase, title case, sentence case)
- Character spacing (tight, normal, wide/tracked out)
- Line spacing

## Layout
- Slide aspect ratio (16:9, 4:3, or custom)
- Margins (top, bottom, left, right) as proportion of slide
- Column structure and widths
- Vertical zones — where each element sits
- Alignment patterns (left-aligned, centered, edge-to-edge)

## Elements (in z-order, bottom to top)
For each element, specify:
- Type (text, shape, image, icon, line, chart)
- Position (x, y as proportion from top-left)
- Size (w, h as proportion of slide)
- Styling (fill, border, shadow, corner radius, opacity)

## Visual Motifs
- Shape treatments (rounded corners? shadow depth? border style?)
- Icon style (outline, filled, in colored circles, monochrome or multicolor)
- Decorative patterns (accent bars, corner marks, background textures)
- Image treatments (rounded, masked, shadowed, full-bleed)

## Slide Classification
- Type: [title | section-divider | content | data-heavy | image-heavy | closing]
- Mood: [corporate | creative | minimal | bold | elegant | playful]

Output as structured JSON matching the design-spec.json schema.
```

## Font Classification Quick Reference

| If it looks like... | Classification | Map to |
|---------------------|---------------|--------|
| Futura, Montserrat, Poppins | Geometric sans | Trebuchet MS |
| Open Sans, Lato, Source Sans | Humanist sans | Calibri |
| Helvetica, Arial, Roboto | Neo-grotesque | Arial |
| Playfair Display, Didot, Bodoni | Modern serif | Georgia |
| Merriweather, Lora | Old-style serif | Palatino |
| Roboto Slab, Rockwell | Slab serif | Cambria |
| IBM Plex Mono, Fira Code | Monospace | Consolas |
| Anton, Oswald, Bebas | Display/condensed | Impact or Arial Black |

## Color Extraction Tips

- Sample colors from flat areas, not where shadows/gradients affect them
- Dark backgrounds often aren't pure black — they're navy (#1A1A2E), charcoal (#2D2D2D), or dark blue-gray (#1E293B)
- White backgrounds often aren't pure white — check for off-white (#F5F5F7), warm gray (#FAFAF9), or cool gray (#F8FAFC)
- Accent colors tend to be saturated but not neon — corporate blues (#0A84FF), greens (#30D158), oranges (#FF9F0A)
