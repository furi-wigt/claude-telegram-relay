# Content Classifier

Parse a markdown file and classify each section into a content type that determines slide layout and visual treatment.

## Parsing Strategy

1. Split markdown by `## ` headings (H2) — each becomes a potential slide
2. The first `# ` heading (H1) becomes the title slide
3. Sections with sub-headings (`### `) may split into multiple slides if content is dense
4. Preserve the original order — slides follow the markdown's narrative flow

## Content Type Definitions

### title-slide
**Pattern**: First H1/H2 heading, or content before the first section break.
**Visual**: Hero layout — large centered text on dark background, optional Gemini-generated background illustration that represents the topic.
**Gemini use**: Background illustration (16:9, topic-specific, design-palette colors).

### section-divider
**Pattern**: An H2 heading with little or no body text (< 20 words), or a heading that introduces a major new topic.
**Visual**: Dark slide with large heading text. Optional subtle background graphic.
**Gemini use**: Optional abstract background pattern.

### narrative
**Pattern**: One or more paragraphs with no structured data (no tables, bullets, numbers).
**Visual**: Text + illustration layout. Left: text block. Right: Gemini-generated spot illustration.
**Gemini use**: Spot illustration (square, topic-related, design-palette constrained).

### key-points
**Pattern**: Bullet list with 3-6 items, where each bullet is a concise point.
**Visual**: Card grid (2x2, 3x1, or 2x3 depending on count). Each card gets an icon and text.
**Gemini use**: Per-item icons — either react-icons (preferred for speed) or Gemini-generated spot icons if the reference deck uses custom illustration-style icons.

### detailed-list
**Pattern**: Bullet list with 7+ items.
**Visual**: Two-column layout with alternating accent bars, or a compact card grid.
**Gemini use**: Section-level illustration only (not per-item).

### stat-callout
**Pattern**: Text containing numbers with units — percentages, dollar amounts, metrics, KPIs. Look for patterns like `$4.2M`, `99.97%`, `+15%`, `340ms`, `2.5x`.
**Visual**: Big number callouts (48-60pt) with trend icons and small labels. 2-4 stats per slide arranged horizontally.
**Gemini use**: Trend icons (react-icons preferred: FaArrowUp, FaArrowDown, FaMinus).

### data-table
**Pattern**: Markdown table syntax (`| Header | Header |`).
**Visual**: Styled PptxGenJS table with header row in primary dark color, alternating stripe rows, palette-matched borders.
**Gemini use**: None typically — tables are built natively. Optional: small illustration beside the table if space allows.

### comparison
**Pattern**: Content with comparison language: "vs", "before/after", "pros/cons", "option A / option B", or two parallel lists.
**Visual**: Side-by-side columns or cards, potentially with a vertical divider. Color-coded (accent1 vs accent2).
**Gemini use**: Optional comparison illustration.

### process-flow
**Pattern**: Numbered list (1. 2. 3.) or sequential steps.
**Visual**: Horizontal timeline with numbered circles, connector lines, and labels. Alternatively, a vertical step diagram.
**Gemini use**: Optional per-step icons.

### technical
**Pattern**: Code blocks (triple backticks).
**Visual**: Dark code card with monospace font, syntax-colored text approximation, rounded corners.
**Gemini use**: None.

### quote
**Pattern**: Blockquote (`> ...`).
**Visual**: Large italic text with accent bar on the left. Attribution line below in caption font.
**Gemini use**: None.

### chart-data
**Pattern**: Data that implies a chart — multiple values across categories, trend data, percentages that add to ~100%.
**Visual**: PptxGenJS native chart (bar, line, pie, doughnut) styled to palette. Or Gemini-generated chart image for complex visualizations.
**Gemini use**: Chart image if native charts can't handle the complexity (e.g., multi-axis, waterfall, Sankey).

### closing
**Pattern**: Last section, or content containing "thank you", "questions?", "contact", email addresses, URLs.
**Visual**: Dark slide, centered text, optional logo placeholder, contact details.
**Gemini use**: Optional background (similar to title slide).

## Classifier Implementation

```javascript
const fs = require("fs");

function parseMarkdown(mdContent) {
  const sections = [];
  // Split by H2, keeping the heading
  const parts = mdContent.split(/^(?=## )/m);
  
  for (const part of parts) {
    const lines = part.trim().split("\n");
    if (!lines[0]) continue;
    
    let heading = "";
    let body = "";
    
    // Check for H1 or H2
    const h1Match = lines[0].match(/^# (.+)/);
    const h2Match = lines[0].match(/^## (.+)/);
    
    if (h1Match) {
      heading = h1Match[1].trim();
      body = lines.slice(1).join("\n").trim();
    } else if (h2Match) {
      heading = h2Match[1].trim();
      body = lines.slice(1).join("\n").trim();
    } else {
      // Content before first heading
      heading = "";
      body = part.trim();
    }
    
    sections.push({ heading, body });
  }
  
  return sections;
}

function classifySection(heading, body, index, totalSections) {
  // Title slide: first section
  if (index === 0) return "title-slide";
  
  // Closing: last section or "thank you" / "questions" / contact
  if (index === totalSections - 1 ||
      /thank\s*you|questions\??|contact|@[\w.-]+\.\w+/i.test(body + heading)) {
    return "closing";
  }
  
  // Section divider: heading with minimal body
  const wordCount = body.split(/\s+/).filter(Boolean).length;
  if (wordCount < 20 && !body.includes("|") && !body.includes("```")) {
    return "section-divider";
  }
  
  // Data table
  if (/^\s*\|.+\|.+\|/m.test(body) && /^\s*\|[-:\s|]+\|/m.test(body)) {
    return "data-table";
  }
  
  // Code block
  if (/```[\s\S]*?```/.test(body)) return "technical";
  
  // Quote
  if (/^>\s/m.test(body)) return "quote";
  
  // Stat callout: numbers with units
  const statPatterns = /\b\d+(\.\d+)?[%$MBKk]\b|\b\$[\d,.]+[MBKk]?\b|\b\d+(\.\d+)?x\b|\+\d+%/g;
  const statMatches = body.match(statPatterns) || [];
  if (statMatches.length >= 2) return "stat-callout";
  
  // Process flow: numbered steps
  const numberedSteps = body.match(/^\s*\d+\.\s/gm) || [];
  if (numberedSteps.length >= 3) return "process-flow";
  
  // Comparison
  if (/\bvs\.?\b|\bbefore\b[\s\S]{0,50}\bafter\b|\bpros?\b[\s\S]{0,30}\bcons?\b|\boption\s+[AB]\b/i.test(body)) {
    return "comparison";
  }
  
  // Bullets
  const bullets = body.match(/^[\s]*[-*]\s/gm) || [];
  if (bullets.length >= 7) return "detailed-list";
  if (bullets.length >= 3) return "key-points";
  
  // Chart data: look for structured numeric data
  const numericLines = body.split("\n").filter(l => /\d/.test(l) && /[,:]/.test(l));
  if (numericLines.length >= 3) return "chart-data";
  
  // Default
  return "narrative";
}

function extractStats(body) {
  const stats = [];
  const lines = body.split("\n");
  for (const line of lines) {
    const numMatch = line.match(/(\$?[\d,.]+[%$MBKk]?x?|\+\d+%)/);
    if (numMatch) {
      const value = numMatch[1];
      const label = line.replace(numMatch[0], "").replace(/^[\s\-*:]+|[\s:]+$/g, "").trim();
      const trend = /\+|up|increase|grow/i.test(line) ? "up"
                  : /\-|down|decrease|drop/i.test(line) ? "down"
                  : "stable";
      stats.push({ value, label, trend });
    }
  }
  return stats;
}

function extractTable(body) {
  const tableLines = body.split("\n").filter(l => l.trim().startsWith("|"));
  if (tableLines.length < 3) return null;
  
  const parseRow = (line) => line.split("|").slice(1, -1).map(c => c.trim());
  const headers = parseRow(tableLines[0]);
  // Skip separator row (index 1)
  const rows = tableLines.slice(2).map(parseRow);
  
  return { headers, rows };
}

function extractBullets(body) {
  return body.split("\n")
    .filter(l => /^\s*[-*]\s/.test(l))
    .map(l => {
      const text = l.replace(/^\s*[-*]\s+/, "").trim();
      // Split into heading:body if colon or bold pattern exists
      const colonMatch = text.match(/^(.+?):\s+(.+)$/);
      const boldMatch = text.match(/^\*\*(.+?)\*\*\s*[-–:]?\s*(.+)$/);
      if (boldMatch) return { heading: boldMatch[1], body: boldMatch[2] };
      if (colonMatch) return { heading: colonMatch[1], body: colonMatch[2] };
      return { heading: text, body: "" };
    });
}

function buildSlidePlan(mdContent) {
  const sections = parseMarkdown(mdContent);
  const slides = [];
  
  sections.forEach((section, i) => {
    const type = classifySection(section.heading, section.body, i, sections.length);
    
    const slide = {
      index: i + 1,
      type,
      heading: section.heading,
      content: section.body,
      visualNeeds: getVisualNeeds(type, section.heading, section.body),
    };
    
    // Type-specific data extraction
    if (type === "stat-callout") slide.stats = extractStats(section.body);
    if (type === "data-table") slide.tableData = extractTable(section.body);
    if (type === "key-points" || type === "detailed-list") slide.bullets = extractBullets(section.body);
    if (type === "process-flow") {
      slide.steps = section.body.split("\n")
        .filter(l => /^\s*\d+\.\s/.test(l))
        .map(l => l.replace(/^\s*\d+\.\s+/, "").trim());
    }
    
    slides.push(slide);
  });
  
  return { slides, totalSlides: slides.length };
}

// Determine what visual assets each slide needs
function getVisualNeeds(type, heading, body) {
  switch (type) {
    case "title-slide":
      return {
        type: "background-illustration",
        description: `Background illustration representing: ${heading}`,
        format: "16:9", size: "1920x1080",
      };
    case "narrative":
      return {
        type: "spot-illustration",
        description: `Illustration for topic: ${heading}`,
        format: "1:1", size: "512x512",
      };
    case "key-points":
      return {
        type: "per-item-icons",
        useReactIcons: true, // prefer react-icons for speed
        fallbackToGemini: true,
      };
    case "section-divider":
      return {
        type: "abstract-background",
        description: `Subtle abstract pattern for section: ${heading}`,
        format: "16:9", size: "1920x1080",
      };
    case "stat-callout":
      return { type: "trend-icons", useReactIcons: true };
    case "closing":
      return {
        type: "background-illustration",
        description: "Professional closing/thank-you background",
        format: "16:9", size: "1920x1080",
      };
    default:
      return { type: "none" };
  }
}

module.exports = { parseMarkdown, classifySection, buildSlidePlan };
```

## Testing the Classifier

Given this sample markdown:

```markdown
# Q3 Cloud Infrastructure Review

## Executive Summary
Our cloud migration is ahead of schedule. We've achieved significant
cost reductions while improving reliability across all services.

## Key Metrics
- **Annual savings**: $4.2M (+15% vs forecast)
- **Uptime SLA**: 99.97%
- **P95 Latency**: 340ms (down from 520ms)

## Service Breakdown
| Service | Cost | Uptime | Owner |
|---------|------|--------|-------|
| API Gateway | $12K/mo | 99.99% | Team A |
| Data Pipeline | $8K/mo | 99.95% | Team B |

## Migration Roadmap
1. Complete VPC peering by Oct 15
2. Migrate remaining databases by Nov 1
3. Decommission legacy servers by Dec 15
4. Final compliance audit in Q1

## Architecture Highlights
> "Simplicity is the ultimate sophistication" — our guiding principle

## Thank You
Questions? Reach out at infra-team@company.com
```

Expected classification:
1. `title-slide` — "Q3 Cloud Infrastructure Review"
2. `narrative` — "Executive Summary" (paragraph, no data)
3. `stat-callout` — "Key Metrics" ($4.2M, 99.97%, 340ms)
4. `data-table` — "Service Breakdown" (markdown table)
5. `process-flow` — "Migration Roadmap" (numbered steps)
6. `quote` — "Architecture Highlights" (blockquote)
7. `closing` — "Thank You" (contact info)
