# Deck Cloner — Example Walkthrough

A complete end-to-end example showing how to use the deck-cloner skill
in Claude Code to turn reference screenshots + a markdown file into
a design-faithful editable .pptx.

---

## Scenario

You have:
1. **3 screenshots** of a client's existing slide deck (their brand style)
2. **A markdown file** with your new content (Q3 infrastructure review)

You want an editable `.pptx` that looks like the client designed it,
with intelligent visual elements (stat cards, styled tables, timelines,
Gemini-generated illustrations).

---

## Step 0: Setup

```bash
# One-time dependency installation
npm install -g pptxgenjs react-icons react react-dom sharp
npm install -g @google/gemini-cli
pip install "markitdown[pptx]" Pillow --break-system-packages

# Authenticate Gemini CLI (one-time)
export GEMINI_API_KEY="your-key-here"
# or run: gemini  (and follow interactive auth)

# Create project directory
mkdir q3-infra-review && cd q3-infra-review
mkdir reference-slides assets
```

Place your reference screenshots in `reference-slides/`:
```
reference-slides/
├── slide-1-title.png      # Dark navy title slide with geometric shapes
├── slide-2-content.png     # Light bg, 2-column cards with blue accent bars
└── slide-3-data.png        # Light bg, styled table with dark header row
```

---

## Step 1: Create your content markdown

Save as `content.md`:

```markdown
# Q3 Cloud Infrastructure Review
Quarterly update for the Infrastructure Steering Committee

## Executive Summary
Our cloud migration is ahead of schedule. We've achieved significant
cost reductions while improving reliability across all production services.
The team has successfully migrated 85% of workloads to AWS, with the
remaining legacy systems targeted for Q4 completion.

## Key Metrics
- **Annual savings**: $4.2M (+15% vs forecast)
- **Uptime SLA**: 99.97% (target: 99.95%)
- **P95 Latency**: 340ms (down from 520ms in Q2)
- **Workloads migrated**: 85% complete

## Service Cost Breakdown
| Service | Monthly Cost | Uptime | Owner | Trend |
|---------|-------------|--------|-------|-------|
| API Gateway | $12,400 | 99.99% | Platform Team | ↓ 8% |
| Data Pipeline | $8,200 | 99.95% | Data Eng | ↓ 12% |
| Auth Service | $3,100 | 99.99% | Security | Stable |
| CDN & Edge | $15,600 | 99.98% | Platform Team | ↓ 5% |
| Monitoring | $4,800 | 100% | SRE | ↑ 3% |

## Security & Compliance
- **IM8 compliance**: All GCC systems passed quarterly audit
- **Penetration testing**: Zero critical findings in Q3
- **IAM cleanup**: Removed 340 stale service accounts
- **Encryption**: 100% at-rest encryption across all data stores
- **MFA adoption**: 98% of privileged accounts enabled
- **Incident response**: MTTR reduced from 45min to 18min

## Migration Roadmap
1. Complete VPC peering for remaining services by Oct 15
2. Migrate PostgreSQL databases to Aurora by Nov 1
3. Decommission legacy on-prem servers by Dec 15
4. Final IM8 compliance audit in January
5. Cost optimization review and right-sizing in February

## Architecture Principles
> "Simplicity is the ultimate sophistication" — our guiding principle
> for every architectural decision this quarter

## Thank You
Questions or feedback?
Contact: infra-team@gov.sg | Slack: #infrastructure
```

---

## Step 2: Launch Claude Code

Open Claude Code in the project directory and give it this prompt:

```
I have reference screenshots in reference-slides/ and my content in content.md.

Using the deck-cloner skill:
1. Analyze the reference screenshots to extract the design DNA
2. Parse content.md and classify each section
3. Use Gemini CLI to generate illustrations that match the reference style
4. Build the final .pptx with PptxGenJS
5. QA and iterate

Make it look like the original designer created this deck.
```

---

## Step 3: What Claude Code does (Phase by Phase)

### Phase 1 — Design DNA Extraction

Claude Code reads each screenshot and produces `design-spec.json`:

```json
{
  "meta": {
    "layout": "LAYOUT_16x9",
    "slideCount": 7,
    "designStyle": "Modern corporate with dark hero slides and light content"
  },
  "palette": {
    "primaryBg": "0F1B2D",
    "secondaryBg": "F4F5F7",
    "headingColor": "FFFFFF",
    "bodyColor": "2D3748",
    "mutedColor": "718096",
    "accent1": "2B6CB0",
    "accent2": "38A169",
    "chartColors": ["2B6CB0", "38A169", "D69E2E", "E53E3E"],
    "tableBorder": "E2E8F0",
    "tableHeaderBg": "0F1B2D",
    "tableStripeBg": "F7FAFC"
  },
  "typography": {
    "headingFont": "Trebuchet MS",
    "bodyFont": "Calibri",
    "captionFont": "Calibri Light",
    "sizes": {
      "heroTitle": 44,
      "slideTitle": 30,
      "sectionHeader": 22,
      "body": 14,
      "caption": 10
    }
  },
  "layout": {
    "margins": { "top": 0.6, "bottom": 0.5, "left": 0.8, "right": 0.8 },
    "contentWidth": 8.4,
    "columnGap": 0.4,
    "verticalGap": 0.3
  },
  "motifs": {
    "cornerRadius": 0.1,
    "iconStyle": "filled-circle",
    "iconSize": 0.4,
    "accentBarWidth": 0.05,
    "dividerStyle": "thin-line",
    "shadowStyle": {
      "type": "outer", "blur": 6, "offset": 2,
      "color": "000000", "opacity": 0.10
    },
    "illustrationStyle": "flat-vector-corporate-geometric"
  }
}
```

### Phase 2 — Content Classification

Claude Code parses `content.md` and produces `slide-plan.json`:

```json
{
  "totalSlides": 8,
  "slides": [
    {
      "index": 1,
      "type": "title-slide",
      "heading": "Q3 Cloud Infrastructure Review",
      "content": "Quarterly update for the Infrastructure Steering Committee",
      "visualNeeds": {
        "type": "background-illustration",
        "description": "Cloud infrastructure with geometric server shapes",
        "format": "16:9",
        "size": "1920x1080"
      }
    },
    {
      "index": 2,
      "type": "narrative",
      "heading": "Executive Summary",
      "content": "Our cloud migration is ahead of schedule...",
      "visualNeeds": {
        "type": "spot-illustration",
        "description": "Cloud migration progress illustration",
        "format": "1:1",
        "size": "512x512"
      }
    },
    {
      "index": 3,
      "type": "stat-callout",
      "heading": "Key Metrics",
      "stats": [
        { "value": "$4.2M", "label": "Annual savings", "trend": "up" },
        { "value": "99.97%", "label": "Uptime SLA", "trend": "up" },
        { "value": "340ms", "label": "P95 Latency", "trend": "down" },
        { "value": "85%", "label": "Workloads migrated", "trend": "up" }
      ],
      "visualNeeds": { "type": "trend-icons", "useReactIcons": true }
    },
    {
      "index": 4,
      "type": "data-table",
      "heading": "Service Cost Breakdown",
      "tableData": {
        "headers": ["Service", "Monthly Cost", "Uptime", "Owner", "Trend"],
        "rows": [
          ["API Gateway", "$12,400", "99.99%", "Platform Team", "↓ 8%"],
          ["Data Pipeline", "$8,200", "99.95%", "Data Eng", "↓ 12%"],
          ["Auth Service", "$3,100", "99.99%", "Security", "Stable"],
          ["CDN & Edge", "$15,600", "99.98%", "Platform Team", "↓ 5%"],
          ["Monitoring", "$4,800", "100%", "SRE", "↑ 3%"]
        ]
      },
      "visualNeeds": { "type": "none" }
    },
    {
      "index": 5,
      "type": "key-points",
      "heading": "Security & Compliance",
      "bullets": [
        { "heading": "IM8 compliance", "body": "All GCC systems passed quarterly audit" },
        { "heading": "Penetration testing", "body": "Zero critical findings in Q3" },
        { "heading": "IAM cleanup", "body": "Removed 340 stale service accounts" },
        { "heading": "Encryption", "body": "100% at-rest encryption across all data stores" },
        { "heading": "MFA adoption", "body": "98% of privileged accounts enabled" },
        { "heading": "Incident response", "body": "MTTR reduced from 45min to 18min" }
      ],
      "visualNeeds": {
        "type": "per-item-icons",
        "useReactIcons": true,
        "fallbackToGemini": true
      }
    },
    {
      "index": 6,
      "type": "process-flow",
      "heading": "Migration Roadmap",
      "steps": [
        "Complete VPC peering for remaining services by Oct 15",
        "Migrate PostgreSQL databases to Aurora by Nov 1",
        "Decommission legacy on-prem servers by Dec 15",
        "Final IM8 compliance audit in January",
        "Cost optimization review and right-sizing in February"
      ],
      "visualNeeds": { "type": "none" }
    },
    {
      "index": 7,
      "type": "quote",
      "heading": "Architecture Principles",
      "content": "> \"Simplicity is the ultimate sophistication\" — our guiding principle\n> for every architectural decision this quarter",
      "visualNeeds": { "type": "none" }
    },
    {
      "index": 8,
      "type": "closing",
      "heading": "Thank You",
      "content": "Questions or feedback?\nContact: infra-team@gov.sg | Slack: #infrastructure",
      "visualNeeds": {
        "type": "background-illustration",
        "description": "Professional closing/thank-you background",
        "format": "16:9",
        "size": "1920x1080"
      }
    }
  ]
}
```

### Phase 3 — Gemini Asset Generation

Claude Code runs the asset pipeline. Here's what Gemini produces:

```
🎨 Deck Cloner Asset Pipeline
   Style: flat-vector-corporate-geometric
   Colors: #2B6CB0, #38A169, #0F1B2D

🖼️  Slide 1 (title-slide): Generating background-illustration...
   ✅ Generated: assets/slide-1-bg.png

🖼️  Slide 2 (narrative): Generating spot-illustration...
   ✅ Generated: assets/slide-2-spot.png

⏭️  Slide 3 (stat-callout): Using react-icons (trend arrows)
⏭️  Slide 4 (data-table): No visual assets needed
⏭️  Slide 5 (key-points): Using react-icons (security icons)
⏭️  Slide 6 (process-flow): No visual assets needed
⏭️  Slide 7 (quote): No visual assets needed

🖼️  Slide 8 (closing): Generating background-illustration...
   ✅ Generated: assets/slide-8-bg.png

════════════════════════════════
📊 Asset Pipeline Summary
   Generated: 3
   Skipped:   5
   Failed:    0
```

The Gemini prompts used looked like:

**Slide 1 (title background):**
```
Generate an image. STYLE RULES: Use ONLY #2B6CB0 (blue), #38A169 (green),
#0F1B2D (dark navy). Style: flat-vector-corporate-geometric. No text.
Background: solid #0F1B2D. 16:9, 1920x1080.

SUBJECT: Subtle geometric illustration of cloud infrastructure —
abstract server nodes, network connections, floating geometric shapes.
Keep center clear for text overlay. Heavier detail on edges.

Save to ./assets/slide-1-bg.png
```

**Slide 2 (spot illustration):**
```
Generate an image. STYLE RULES: Use ONLY #2B6CB0 (blue), #38A169 (green).
Style: flat-vector-corporate-geometric. No text.
Background: white. 1:1, 512x512.

SUBJECT: Flat vector illustration of cloud migration progress —
servers moving to cloud, progress bar concept, upward momentum.

Save to ./assets/slide-2-spot.png
```

### Phase 4 — PptxGenJS Assembly

Claude Code generates `generate-deck.js` based on the scaffold, filling in:
- Design tokens from `design-spec.json`
- Slide plan routing from `slide-plan.json`
- Asset paths from `assets/`

Then runs it:

```
$ node generate-deck.js
📦 Loaded 3 visual assets
📝 Slide 1/8: title-slide — "Q3 Cloud Infrastructure Review"
📝 Slide 2/8: narrative — "Executive Summary"
📝 Slide 3/8: stat-callout — "Key Metrics"
📝 Slide 4/8: data-table — "Service Cost Breakdown"
📝 Slide 5/8: key-points — "Security & Compliance"
📝 Slide 6/8: process-flow — "Migration Roadmap"
📝 Slide 7/8: quote — "Architecture Principles"
📝 Slide 8/8: closing — "Thank You"

✅ Created: output.pptx (8 slides)
```

### Phase 5 — QA

Claude Code converts to images and inspects:

```bash
python soffice.py --headless --convert-to pdf output.pptx
pdftoppm -jpeg -r 150 output.pdf slide
```

Then compares each slide image against the reference screenshots:

```
QA Report:
  Slide 1 ✅ Background matches dark navy, title positioned correctly
  Slide 2 ✅ Two-column layout, spot illustration on right
  Slide 3 ⚠️  Stat cards — accent bar slightly too thick (0.06 vs 0.05)
  Slide 4 ✅ Table header matches dark row from reference
  Slide 5 ⚠️  Icon circles need to use accent1 blue, currently gray
  Slide 6 ✅ Timeline circles and dashed connectors look good
  Slide 7 ✅ Quote styling matches with accent bar
  Slide 8 ✅ Closing slide background works

Fixing 2 issues...
  → Adjusted accentBarWidth to 0.05
  → Updated icon circle fill from gray to accent1

Re-running... ✅ All slides pass QA
```

---

## Final Output

```
q3-infra-review/
├── reference-slides/
│   ├── slide-1-title.png
│   ├── slide-2-content.png
│   └── slide-3-data.png
├── content.md                  ← Your input
├── design-spec.json            ← Reusable for future decks!
├── slide-plan.json             ← Content classification
├── assets/
│   ├── slide-1-bg.png          ← Gemini: title background
│   ├── slide-2-spot.png        ← Gemini: narrative illustration
│   └── slide-8-bg.png          ← Gemini: closing background
├── generate-deck.js            ← Editable, re-runnable script
└── output.pptx                 ← Your final deck ✅
```

---

## What Each Slide Looks Like

| # | Type | Layout | Visual Elements |
|---|------|--------|-----------------|
| 1 | **Title** | Dark bg, centered text | Gemini geometric illustration, large 44pt heading |
| 2 | **Narrative** | Light bg, 2-column | Text left, Gemini spot illustration right |
| 3 | **Stat callout** | Light bg, 4 cards | Big numbers (48pt), accent bars, trend arrows |
| 4 | **Data table** | Light bg, full-width | Styled table: dark header, striped rows, palette borders |
| 5 | **Key points** | Light bg, 2x3 grid | 6 cards with icons, bold heading + description |
| 6 | **Process flow** | Light bg, horizontal | 5 numbered circles with dashed connectors |
| 7 | **Quote** | Light bg, accent bar | Large italic text with blue vertical bar |
| 8 | **Closing** | Dark bg, centered | Gemini background, "Thank You", contact info |

---

## Re-using for Different Content

The beauty of this approach: `design-spec.json` is reusable. Next time:

```bash
# Same client style, different content:
cp design-spec.json ../q4-review/
# Write new content.md
# Run Claude Code — it skips Phase 1 (design already extracted)
# and goes straight to classify → generate → build
```

You can also manually edit `design-spec.json` to tweak colors, fonts,
or spacing without touching the code.
