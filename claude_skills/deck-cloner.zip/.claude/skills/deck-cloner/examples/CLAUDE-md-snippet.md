# Deck Cloner — CLAUDE.md Directive

Add the following to your project's `CLAUDE.md` (or `~/.claude/CLAUDE.md` for global)
to ensure Claude Code always routes deck cloning through the full creative pipeline.

---

## Snippet to add:

```markdown
## Deck Cloning Rules

When I provide a .pptx file along with separate content (markdown, text, outline)
and ask to "clone", "replicate", "match the style", or create a new deck that
"looks like" the reference:

1. **NEVER** use the generic pptx editing workflow (unpack → edit XML → repack)
2. **ALWAYS** use the deck-cloner skill's full pipeline
3. **ALWAYS** run `python scripts/pptx-preprocess.py` first to:
   - Convert .pptx slides to images (reference-slides/)
   - Extract design tokens from XML (extracted-tokens.json)
4. Then continue with vision analysis → content classification → Gemini assets → PptxGenJS → QA

The goal is a NEW deck built from scratch with PptxGenJS that replicates the
visual DNA of the reference — not a modified copy of the original file.
```

---

## Why this is needed

The default `pptx` skill in Claude Code has a very broad trigger:
> "trigger whenever a .pptx file is involved in any way"

When you provide a `.pptx` as a design reference alongside markdown content,
Claude Code sees the `.pptx` file and activates the generic editing skill,
which unpacks the XML and swaps in your content — bypassing:

- Creative design analysis (Phase 1)
- Content-aware slide planning (Phase 2)
- Gemini visual asset generation (Phase 3)
- Content-type-specific layouts like stat callouts, styled tables, timelines (Phase 4)

The CLAUDE.md directive overrides this by establishing an explicit rule
that the deck-cloner pipeline takes priority for design replication tasks.
