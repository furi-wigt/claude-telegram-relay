"""t3 — Things 3 CLI. Single installed command via uv tool install."""

import argparse
import json
import subprocess
import sys
import urllib.parse

VALID_REPEAT = {"daily", "weekly", "monthly", "yearly"}
VALID_WHEN = {"today", "tomorrow", "evening", "anytime", "someday"}


# ── helpers ──────────────────────────────────────────────────────────────────

def get_things():
    try:
        import things
        return things
    except ImportError:
        _die("things.py not installed. Run: uv tool install --editable ~/.claude/skills/things")


def get_token():
    things = get_things()
    token = things.token()
    if not token:
        _die("Things auth token missing. Enable: Things > Settings > General > Enable Things URLs > Copy Link")
    return token


def _die(msg: str):
    print(f"Error: {msg}", file=sys.stderr)
    sys.exit(1)


def _open(url: str):
    subprocess.run(["open", url], check=True)


def _encode(params: dict) -> str:
    return urllib.parse.urlencode(params, quote_via=urllib.parse.quote)


def _out(data):
    """JSON output for all read commands."""
    print(json.dumps(data, indent=2, default=str))


def _validate_repeat(value: str) -> str:
    if value not in VALID_REPEAT:
        _die(f"Invalid --repeat '{value}'. Valid values: {', '.join(sorted(VALID_REPEAT))}")
    return value


# ── read commands ─────────────────────────────────────────────────────────────

def cmd_list(view: str, tag: str | None = None):
    things = get_things()
    view_map = {
        "today": things.today,
        "inbox": things.inbox,
        "upcoming": things.upcoming,
        "anytime": things.anytime,
        "someday": things.someday,
        "logbook": things.logbook,
        "deadlines": things.deadlines,
        "completed": things.completed,
    }
    fn = view_map.get(view)
    if not fn:
        _die(f"Unknown view '{view}'. Valid: {', '.join(view_map)}")
    kwargs = {"tag": tag} if tag else {}
    _out(fn(**kwargs))


def cmd_projects(args):
    _out(get_things().projects())


def cmd_areas(args):
    _out(get_things().areas())


def cmd_search(args):
    _out(get_things().search(args.query))


def cmd_show(args):
    item = get_things().get(args.uuid)
    if not item:
        _die(f"Not found: {args.uuid}")
    _out(item)


# ── task write commands ───────────────────────────────────────────────────────

def cmd_add(args):
    params = {"title": args.title}
    if args.when:
        params["when"] = args.when
    if args.tags:
        params["tags"] = args.tags
    if args.notes:
        params["notes"] = args.notes
    if args.deadline:
        params["deadline"] = args.deadline
    if args.list:
        params["list"] = args.list
    if args.list_id:
        params["list-id"] = args.list_id
    if args.heading:
        params["heading"] = args.heading
    if args.checklist:
        params["checklist-items"] = "\n".join(args.checklist.split(","))
    if args.repeat:
        params["repeat"] = _validate_repeat(args.repeat)
    _open("things:///add?" + _encode(params))
    print(f"Added: {args.title}")


def cmd_update(args):
    token = get_token()
    params = {"id": args.uuid, "auth-token": token}
    if args.title:
        params["title"] = args.title
    if args.notes:
        params["notes"] = args.notes
    if args.prepend_notes:
        params["prepend-notes"] = args.prepend_notes
    if args.append_notes:
        params["append-notes"] = args.append_notes
    if args.when:
        params["when"] = args.when
    if args.deadline:
        params["deadline"] = args.deadline
    if args.tags:
        params["tags"] = args.tags
    if args.add_tags:
        params["add-tags"] = args.add_tags
    if args.list:
        params["list"] = args.list
    if args.list_id:
        params["list-id"] = args.list_id
    if args.heading:
        params["heading"] = args.heading
    if args.checklist:
        params["checklist-items"] = "\n".join(args.checklist.split(","))
    if len(params) == 2:  # only id + token
        _die("No fields to update. Provide at least one flag.")
    _open("things:///update?" + _encode(params))
    print(f"Updated: {args.uuid}")


def cmd_complete(args):
    get_things().complete(args.uuid)
    print(f"Completed: {args.uuid}")


def cmd_uncomplete(args):
    token = get_token()
    params = {"id": args.uuid, "auth-token": token, "completed": "false"}
    _open("things:///update?" + _encode(params))
    print(f"Uncompleted: {args.uuid}")


def cmd_cancel(args):
    token = get_token()
    params = {"id": args.uuid, "auth-token": token, "canceled": "true"}
    _open("things:///update?" + _encode(params))
    print(f"Cancelled: {args.uuid}")


# ── project commands ──────────────────────────────────────────────────────────

def cmd_add_project(args):
    params = {"title": args.title}
    if args.when:
        params["when"] = args.when
    if args.notes:
        params["notes"] = args.notes
    if args.deadline:
        params["deadline"] = args.deadline
    if args.tags:
        params["tags"] = args.tags
    if args.area:
        params["area"] = args.area
    if args.area_id:
        params["area-id"] = args.area_id
    if args.todos:
        params["to-dos"] = "\n".join(args.todos.split(","))
    _open("things:///add-project?" + _encode(params))
    print(f"Project added: {args.title}")


def cmd_update_project(args):
    token = get_token()
    params = {"id": args.uuid, "auth-token": token}
    if args.title:
        params["title"] = args.title
    if args.notes:
        params["notes"] = args.notes
    if args.prepend_notes:
        params["prepend-notes"] = args.prepend_notes
    if args.append_notes:
        params["append-notes"] = args.append_notes
    if args.when:
        params["when"] = args.when
    if args.deadline:
        params["deadline"] = args.deadline
    if args.tags:
        params["tags"] = args.tags
    if args.add_tags:
        params["add-tags"] = args.add_tags
    if args.area:
        params["area"] = args.area
    if args.area_id:
        params["area-id"] = args.area_id
    if len(params) == 2:
        _die("No fields to update. Provide at least one flag.")
    _open("things:///update-project?" + _encode(params))
    print(f"Project updated: {args.uuid}")


# ── parser ────────────────────────────────────────────────────────────────────

def _add_update_args(p, include_repeat=False):
    """Shared args for add/update operations."""
    p.add_argument("--when", help="today | tomorrow | evening | anytime | someday | yyyy-mm-dd")
    p.add_argument("--deadline", help="Due date yyyy-mm-dd")
    p.add_argument("--tags", help="Comma-separated tags (replaces existing)")
    p.add_argument("--notes", help="Task notes (replaces existing)")
    p.add_argument("--list", help="Project or area name")
    p.add_argument("--list-id", dest="list_id", help="Project or area UUID")
    p.add_argument("--heading", help="Heading within project")
    p.add_argument("--checklist", help="Comma-separated checklist items")
    if include_repeat:
        p.add_argument("--repeat", help="Recurrence: daily | weekly | monthly | yearly")


def _add_update_only_args(p):
    """Args only valid for update (not add)."""
    p.add_argument("--add-tags", dest="add_tags", help="Add tags without removing existing")
    p.add_argument("--prepend-notes", dest="prepend_notes", help="Prepend to existing notes")
    p.add_argument("--append-notes", dest="append_notes", help="Append to existing notes")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="t3",
        description="Things 3 CLI — fast task management",
    )
    sub = parser.add_subparsers(dest="command", metavar="COMMAND")

    # ── read views ──
    for view in ("today", "inbox", "upcoming", "anytime", "someday", "deadlines", "logbook", "completed"):
        p = sub.add_parser(view, help=f"List {view} tasks (JSON)")
        p.add_argument("--tag", help="Filter by tag")
        p.set_defaults(func=lambda a, v=view: cmd_list(v, a.tag))

    # ── read detail ──
    p = sub.add_parser("projects", help="List all projects (JSON)")
    p.set_defaults(func=cmd_projects)

    p = sub.add_parser("areas", help="List all areas (JSON)")
    p.set_defaults(func=cmd_areas)

    p = sub.add_parser("search", help="Search tasks (JSON)")
    p.add_argument("query")
    p.set_defaults(func=cmd_search)

    p = sub.add_parser("show", help="Show task/project details (JSON)")
    p.add_argument("uuid")
    p.set_defaults(func=cmd_show)

    # ── task CRUD ──
    p = sub.add_parser("add", help="Create a task")
    p.add_argument("title")
    _add_update_args(p, include_repeat=True)
    p.set_defaults(func=cmd_add)

    p = sub.add_parser("update", help="Update a task (requires auth token)")
    p.add_argument("uuid")
    p.add_argument("--title", help="New title")
    _add_update_args(p)
    _add_update_only_args(p)
    p.set_defaults(func=cmd_update)

    p = sub.add_parser("complete", help="Mark task completed")
    p.add_argument("uuid")
    p.set_defaults(func=cmd_complete)

    p = sub.add_parser("uncomplete", help="Mark task incomplete")
    p.add_argument("uuid")
    p.set_defaults(func=cmd_uncomplete)

    p = sub.add_parser("cancel", help="Cancel (soft-delete) a task")
    p.add_argument("uuid")
    p.set_defaults(func=cmd_cancel)

    # ── project CRUD ──
    p = sub.add_parser("add-project", help="Create a project")
    p.add_argument("title")
    p.add_argument("--when", help="today | tomorrow | anytime | someday | yyyy-mm-dd")
    p.add_argument("--notes")
    p.add_argument("--deadline", help="yyyy-mm-dd")
    p.add_argument("--tags", help="Comma-separated tags")
    p.add_argument("--area", help="Area name")
    p.add_argument("--area-id", dest="area_id", help="Area UUID")
    p.add_argument("--todos", help="Comma-separated initial to-do titles")
    p.set_defaults(func=cmd_add_project)

    p = sub.add_parser("update-project", help="Update a project (requires auth token)")
    p.add_argument("uuid")
    p.add_argument("--title")
    p.add_argument("--when")
    p.add_argument("--notes")
    p.add_argument("--deadline", help="yyyy-mm-dd")
    p.add_argument("--tags")
    p.add_argument("--add-tags", dest="add_tags")
    p.add_argument("--area")
    p.add_argument("--area-id", dest="area_id")
    p.add_argument("--prepend-notes", dest="prepend_notes")
    p.add_argument("--append-notes", dest="append_notes")
    p.set_defaults(func=cmd_update_project)

    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()
    if not args.command:
        parser.print_help()
        sys.exit(0)
    args.func(args)


if __name__ == "__main__":
    main()
