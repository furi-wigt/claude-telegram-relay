---
name: things
description: Manage tasks in Things 3 on macOS — list, add, complete, cancel, update tasks and projects. Use when the user says "add to Things", "Things 3", "create task", "remind me to", "add todo", "show today's tasks", "complete task", or any task management request.
---

# Things 3 Task Management

This skill manages Things 3 via `t3` — a single installed CLI command.

## Setup (one-time)

```bash
uv tool install --editable ~/.claude/skills/things
```

After install, `t3` is available as a system command. No UV overhead on every call.

To update after code changes:
```bash
uv tool upgrade things-skill
```

## Usage

All read operations output **JSON**. Write operations print a confirmation line.

### Read

```bash
t3 today                          # Today's tasks
t3 inbox                          # Inbox
t3 upcoming                       # Upcoming
t3 deadlines                      # Tasks with deadlines
t3 someday                        # Someday tasks
t3 today --tag Work               # Filter by tag
t3 projects                       # All projects
t3 areas                          # All areas (read-only)
t3 search "quarterly"             # Search by keyword
t3 show <uuid>                    # Full task details
```

### Task CRUD

```bash
# Create
t3 add "Buy groceries" --when today --tags Errand --deadline 2026-03-20
t3 add "Weekly review" --when today --repeat weekly
t3 add "Task in project" --list "My Project" --heading "Sprint 1"
t3 add "With checklist" --checklist "Step 1,Step 2,Step 3"

# Update (requires Things auth token)
t3 update <uuid> --title "New title"
t3 update <uuid> --when tomorrow --deadline 2026-03-25
t3 update <uuid> --append-notes "Follow-up needed"
t3 update <uuid> --add-tags Urgent
t3 update <uuid> --list "Other Project"

# Complete / Cancel
t3 complete <uuid>
t3 uncomplete <uuid>
t3 cancel <uuid>                  # Soft-delete: marks as cancelled
```

### Project CRUD

```bash
# Create
t3 add-project "Q2 Planning" --when today --area "Work"
t3 add-project "Sprint 5" --deadline 2026-04-01 --todos "Define scope,Set milestones,Review"

# Update (requires Things auth token)
t3 update-project <uuid> --title "Q2 Planning (updated)"
t3 update-project <uuid> --deadline 2026-04-15 --add-tags Important
```

### Recurrence (`--repeat`)

Valid values: `daily` | `weekly` | `monthly` | `yearly`

Only supported on `add`. Things 3 URL scheme does not support changing recurrence on existing tasks.

```bash
t3 add "Daily standup" --when today --repeat daily
t3 add "Monthly review" --when today --repeat monthly
```

## Parameters Reference

| Flag | Commands | Description |
|------|----------|-------------|
| `--when` | add, update, add-project, update-project | `today\|tomorrow\|evening\|anytime\|someday\|yyyy-mm-dd` |
| `--deadline` | add, update, add-project, update-project | `yyyy-mm-dd` |
| `--tags` | add, update, add-project, update-project | Comma-separated; **replaces** existing tags |
| `--add-tags` | update, update-project | Comma-separated; **appends** to existing tags |
| `--notes` | add, update | Replaces existing notes |
| `--prepend-notes` | update, update-project | Prepends to existing notes |
| `--append-notes` | update, update-project | Appends to existing notes |
| `--list` | add, update | Project or area name |
| `--list-id` | add, update | Project or area UUID (takes precedence over `--list`) |
| `--heading` | add, update | Heading title within a project |
| `--checklist` | add, update | Comma-separated checklist items |
| `--repeat` | add only | `daily\|weekly\|monthly\|yearly` |
| `--area` | add-project, update-project | Area name |
| `--area-id` | add-project, update-project | Area UUID |
| `--todos` | add-project | Comma-separated initial to-do titles |

## Auth Token

`update`, `uncomplete`, `cancel`, `update-project` require a Things auth token.

Things stores this automatically. If missing:
> Things > Settings > General > Enable Things URLs > Copy Link

## Notes

- **Area writes**: Not supported. Things 3 has no URL scheme for creating/modifying areas.
- **Project delete**: Not supported. Things 3 URL scheme has no project deletion endpoint.
- **Hard task delete**: Not supported. Use `t3 cancel <uuid>` instead.
